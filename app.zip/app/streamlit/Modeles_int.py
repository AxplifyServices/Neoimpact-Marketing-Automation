from __future__ import annotations

import os
import sys
from typing import Any, Dict, List, Optional

import streamlit as st

# --- Fix imports "app.*" pour Streamlit ---
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".", "."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.streamlit._modele_graph import build_dot_from_liste_action

from app.domain.modele import modalites_for, objectif_label
from app.domain.canaux import list_canaux, action_for_canal, resultats_for_canal, compteur_for_canal

# ✅ Façade (plus de DB/store direct dans l'UI)
from app.domain.ui_facades.modeles_ui_facade import (
    get_variable_choices_for_ui,
    list_modeles_for_ui,
    get_locked_modele_ids_for_ui,
    delete_modele_for_ui,
    get_modele_edit_payload_for_ui,
    save_modele_for_ui,
    get_actions_from_row_for_ui,
    get_client_condition_fields_for_ui,
    # ✅ NEW
    get_clients_campagnes_condition_fields_for_ui,
    build_multi_objectif_json_for_ui,
)


# =========================================================
# Helpers UI
# =========================================================
def _pick(d: dict, *keys, default=""):
    for k in keys:
        v = d.get(k, None)
        if v is None:
            continue
        s = str(v).strip()
        if s != "":
            return v
    return default


# =========================================================
# Suppression cascade bloc + descendants
# =========================================================
def _descendants_ids(blocks: List[Dict[str, Any]], root_id: int) -> List[int]:
    children_map: Dict[int, List[int]] = {}
    for b in blocks:
        if b.get("Action") == "Closed":
            continue
        bid = b.get("ID")
        parent = str(b.get("Bloc_mère", "")).strip()
        if isinstance(bid, int) and parent.isdigit():
            children_map.setdefault(int(parent), []).append(int(bid))

    to_delete = set()
    stack = [root_id]
    while stack:
        cur = stack.pop()
        if cur in to_delete:
            continue
        to_delete.add(cur)
        for child in children_map.get(cur, []):
            stack.append(child)

    return list(to_delete)


def _parent_id_of(blocks: List[Dict[str, Any]], node_id: int) -> Optional[int]:
    b = next((x for x in blocks if x.get("ID") == node_id), None)
    if not b:
        return None
    parent = str(b.get("Bloc_mère", "")).strip()
    return int(parent) if parent.isdigit() else None


# =========================================================
# Conditions dépendantes du bloc mère (UPDATED)
# - Ajoute uniquement "NB jours depuis début de la campagne"
# - Retire Resultat_last_action / NB_jour_last_action (doublons)
# =========================================================
def render_condition_builder(
    bloc_mere: Dict[str, Any],
    key_prefix: str,
    initial_conds: Optional[List[Dict[str, Any]]] = None,
    show_existing: bool = True,
) -> List[Dict[str, Any]]:
    conds_key = f"{key_prefix}_conds"
    init_key = f"{key_prefix}_conds__init"

    if conds_key not in st.session_state:
        st.session_state[conds_key] = []

    if initial_conds is not None and not st.session_state.get(init_key, False):
        st.session_state[conds_key] = list(initial_conds or [])
        st.session_state[init_key] = True

    canal_mere = str(bloc_mere.get("Canal", "")).strip()

    if canal_mere in list_canaux():
        compteur = compteur_for_canal(canal_mere)
        flag_values = resultats_for_canal(canal_mere)
    else:
        compteur = "NB_message"
        flag_values = []

    # Champs "système" historiques
    fields = ["Flag résultats", "NB jours depuis last action", compteur]

    # Champs clients.*
    client_meta = get_client_condition_fields_for_ui() or []
    client_labels: List[str] = [f"Client: {d.get('col')}" for d in client_meta if d.get("col")]
    client_label_to_meta = {f"Client: {d.get('col')}": d for d in client_meta if d.get("col")}

    # Champs clients_campagnes (on ne garde QUE nb_jour_debut_campagne)
    cc_meta = get_clients_campagnes_condition_fields_for_ui() or []
    cc_labels: List[str] = []
    cc_label_to_meta: Dict[str, Dict[str, str]] = {}
    for d in cc_meta:
        col = (d.get("col") or "").strip()
        if col != "nb_jour_debut_campagne":
            continue
        lbl = "NB jours depuis début de la campagne"
        cc_labels.append(lbl)
        cc_label_to_meta[lbl] = d

    def _is_client_label(lbl: str) -> bool:
        return isinstance(lbl, str) and lbl.startswith("Client: ")

    def _is_cc_label(lbl: str) -> bool:
        return lbl in cc_label_to_meta

    def _label_from_stored(field_name: str) -> str:
        f = str(field_name or "")
        if f.startswith("client."):
            return f"Client: {f.split('.', 1)[1]}"
        if f == "nb_jour_debut_campagne":
            return "NB jours depuis début de la campagne"
        return f

    def _stored_from_label(lbl: str) -> str:
        if _is_client_label(lbl):
            return "client." + lbl.split("Client: ", 1)[1].strip()
        if _is_cc_label(lbl):
            return "nb_jour_debut_campagne"
        return lbl

    st.markdown("**Conditions (liées au bloc mère sélectionné)**")

    c1, c2, c3, c4 = st.columns([3, 2, 3, 2])
    all_fields_new = fields + cc_labels + client_labels

    with c1:
        field = st.selectbox("Champ", all_fields_new, key=f"{key_prefix}_field_new")

    with c2:
        if field == "Flag résultats":
            op = "="
            st.text_input("Opérateur", value="=", disabled=True, key=f"{key_prefix}_op_new_lock")
        elif (
            (_is_client_label(field) and client_label_to_meta.get(field, {}).get("is_numeric") == "0")
            or (_is_cc_label(field) and cc_label_to_meta.get(field, {}).get("is_numeric") == "0")
        ):
            op = st.selectbox("Opérateur", ["=", "!=", "contains", "not contains"], key=f"{key_prefix}_op_new_txt")
        else:
            op = st.selectbox("Opérateur", ["=", ">", "<", ">=", "<="], key=f"{key_prefix}_op_new")

    with c3:
        if field == "Flag résultats":
            if flag_values:
                value = st.selectbox("Valeur", flag_values, key=f"{key_prefix}_val_new_flag")
            else:
                value = ""
                st.text_input("Valeur", value="", disabled=True, key=f"{key_prefix}_val_new_flag_empty")
        elif (
            (_is_client_label(field) and client_label_to_meta.get(field, {}).get("is_numeric") == "0")
            or (_is_cc_label(field) and cc_label_to_meta.get(field, {}).get("is_numeric") == "0")
        ):
            value = st.text_input("Valeur", value="", key=f"{key_prefix}_val_new_txt")
        else:
            value = st.number_input("Valeur", min_value=0, step=1, value=0, key=f"{key_prefix}_val_new_num")

    with c4:
        if st.button("➕", key=f"{key_prefix}_add"):
            st.session_state[conds_key].append({"field": _stored_from_label(field), "op": op, "value": value})
            st.rerun()

    if show_existing and st.session_state[conds_key]:
        st.markdown("**Conditions existantes**")
        ops = ["=", ">", "<", ">=", "<="]
        all_fields = fields + cc_labels + client_labels

        for i, c in enumerate(list(st.session_state[conds_key])):
            l, m, r = st.columns([4, 4, 1])

            with l:
                cur_field_label = _label_from_stored(c.get("field"))
                new_field = st.selectbox(
                    "Champ",
                    all_fields,
                    index=all_fields.index(cur_field_label) if cur_field_label in all_fields else 0,
                    key=f"{key_prefix}_field_{i}",
                    label_visibility="collapsed",
                )

            with m:
                # Op
                if new_field == "Flag résultats":
                    new_op = "="
                    st.text_input("Op", value="=", disabled=True, key=f"{key_prefix}_op_{i}_lock", label_visibility="collapsed")
                elif (
                    (_is_client_label(new_field) and client_label_to_meta.get(new_field, {}).get("is_numeric") == "0")
                    or (_is_cc_label(new_field) and cc_label_to_meta.get(new_field, {}).get("is_numeric") == "0")
                ):
                    cur_op = c.get("op") if c.get("op") in ["=", "!=", "contains", "not contains"] else "="
                    new_op = st.selectbox(
                        "Op",
                        ["=", "!=", "contains", "not contains"],
                        index=["=", "!=", "contains", "not contains"].index(cur_op),
                        key=f"{key_prefix}_op_{i}_txt",
                        label_visibility="collapsed",
                    )
                else:
                    cur_op = c.get("op") if c.get("op") in ops else "="
                    new_op = st.selectbox(
                        "Op",
                        ops,
                        index=ops.index(cur_op),
                        key=f"{key_prefix}_op_{i}",
                        label_visibility="collapsed",
                    )

                # Valeur
                if new_field == "Flag résultats":
                    cur_val = str(c.get("value", "") or "")
                    if flag_values:
                        idx = flag_values.index(cur_val) if cur_val in flag_values else 0
                        new_val = st.selectbox(
                            "Valeur",
                            flag_values,
                            index=idx,
                            key=f"{key_prefix}_val_{i}_flag",
                            label_visibility="collapsed",
                        )
                    else:
                        new_val = ""
                        st.text_input("Valeur", value="", disabled=True, key=f"{key_prefix}_val_{i}_flag_empty", label_visibility="collapsed")
                elif (
                    (_is_client_label(new_field) and client_label_to_meta.get(new_field, {}).get("is_numeric") == "0")
                    or (_is_cc_label(new_field) and cc_label_to_meta.get(new_field, {}).get("is_numeric") == "0")
                ):
                    cur_val_txt = str(c.get("value", "") or "")
                    new_val = st.text_input("Valeur", value=cur_val_txt, key=f"{key_prefix}_val_{i}_txt", label_visibility="collapsed")
                else:
                    try:
                        cur_val_num = int(float(c.get("value") or 0))
                    except Exception:
                        cur_val_num = 0
                    new_val = st.number_input(
                        "Valeur",
                        min_value=0,
                        step=1,
                        value=cur_val_num,
                        key=f"{key_prefix}_val_{i}_num",
                        label_visibility="collapsed",
                    )

                st.session_state[conds_key][i] = {"field": _stored_from_label(new_field), "op": new_op, "value": new_val}

            with r:
                if st.button("🗑️", key=f"{key_prefix}_del_{i}"):
                    st.session_state[conds_key].pop(i)
                    st.rerun()

    return list(st.session_state[conds_key])


# =========================================================
# Mode édition
# =========================================================
def _enter_edit_modele(id_modele: str) -> None:
    payload = get_modele_edit_payload_for_ui(id_modele) or {}

    st.session_state["edit_modele_id"] = str(id_modele)
    st.session_state["edit_nom_modele"] = str(payload.get("nom_modele") or "").strip()
    st.session_state["edit_variable_cible"] = str(payload.get("variable_cible") or "").strip()
    st.session_state["edit_objectif"] = payload.get("objectif")

    blocks = payload.get("blocks") or []
    if not isinstance(blocks, list):
        blocks = []
    st.session_state["new_blocks"] = blocks

    st.session_state["selected_bm"] = None
    st.session_state.pop("cond_builder_conds", None)
    st.session_state.pop("cond_builder_conds__init", None)

    st.session_state.pop("multi_obj_items", None)
    st.session_state["create_mode"] = True


def _exit_edit_modele() -> None:
    st.session_state["edit_modele_id"] = None
    st.session_state["edit_nom_modele"] = ""
    st.session_state["edit_variable_cible"] = ""
    st.session_state["edit_objectif"] = None


# =========================================================
# UI
# =========================================================
def main():
    st.session_state.setdefault("create_mode", False)
    st.session_state.setdefault("new_blocks", [])
    st.session_state.setdefault("selected_bm", None)

    st.session_state.setdefault("edit_modele_id", None)
    st.session_state.setdefault("edit_nom_modele", "")
    st.session_state.setdefault("edit_variable_cible", "")
    st.session_state.setdefault("edit_objectif", None)

    top = st.columns([6, 1])
    top[0].title("🧠 Modèles")
    if top[1].button("➕", use_container_width=True):
        _exit_edit_modele()
        st.session_state.pop("multi_obj_items", None)
        st.session_state.create_mode = True

    # =====================================================
    # CREATE / EDIT
    # =====================================================
    if st.session_state.create_mode:
        st.subheader("Créer un modèle")

        is_editing = bool(st.session_state.get("edit_modele_id"))
        if is_editing:
            st.caption(f"✏️ Modification du modèle : {st.session_state.get('edit_modele_id')}")

        default_nom = st.session_state.get("edit_nom_modele", "") if is_editing else ""
        nom_modele = st.text_input("Nom du modèle", value=default_nom).strip()

        variable_choices, categorical_cols_allowed, numeric_cols = get_variable_choices_for_ui()
        if not variable_choices:
            st.error("Aucune colonne cible disponible.")
            st.stop()

        default_var = st.session_state.get("edit_variable_cible", "") if is_editing else ""
        var_index = variable_choices.index(default_var) if (default_var in variable_choices) else 0
        variable_cible = st.selectbox("Colonne cible", variable_choices, index=var_index)

        # =====================================================
        # ✅ Objectif MULTI (toujours)
        # - Critère principal = variable_cible
        # - Critères additionnels via ➕ (optionnels)
        # - Type déduit : num => min/max ; cat => modalités
        # =====================================================
        st.markdown("### Objectif (multi AND/OR)")
        op = st.selectbox("Opérateur", ["AND", "OR"], index=0)

        numeric_set = set(numeric_cols or [])
        st.session_state.setdefault("multi_obj_items", [])

        def _var_type(v: str) -> str:
            return "num" if v in numeric_set else "cat"

        objectif_value_for_store = ""
        objectif_label_for_ui = ""

        # --- Critère principal (colonne cible) ---
        st.markdown("**Critère principal (colonne cible)**")
        main_type = _var_type(variable_cible)

        if main_type == "cat":
            mods = modalites_for(variable_cible) or []
            main_value = st.selectbox("Valeur (colonne cible)", mods, index=0, key="main_obj_cat") if mods else ""
            main_item = {"variable": variable_cible, "type": "cat", "value": main_value}
        else:
            c1, c2 = st.columns(2)
            with c1:
                mn_txt = st.text_input("Min (colonne cible)", value="", placeholder="vide = pas de borne", key="main_obj_min")
            with c2:
                mx_txt = st.text_input("Max (colonne cible)", value="", placeholder="vide = pas de borne", key="main_obj_max")

            main_item = {"variable": variable_cible, "type": "num"}
            if str(mn_txt).strip() != "":
                main_item["min"] = float(mn_txt)
            if str(mx_txt).strip() != "":
                main_item["max"] = float(mx_txt)

        # --- Critères additionnels ---
        st.markdown("**Critères additionnels (optionnels)**")
        addA, addB, addC = st.columns([5, 4, 1])
        with addA:
            extra_var = st.selectbox("Variable", variable_choices, key="extra_var")

        extra_type = _var_type(extra_var)
        with addB:
            if extra_type == "cat":
                mods2 = modalites_for(extra_var) or []
                extra_val = st.selectbox("Valeur", mods2, key="extra_val_cat") if mods2 else st.text_input("Valeur", value="", key="extra_val_cat_txt")
                extra_payload = {"variable": extra_var, "type": "cat", "value": extra_val}
            else:
                cmin, cmax = st.columns(2)
                with cmin:
                    extra_min = st.text_input("Min", value="", key="extra_min")
                with cmax:
                    extra_max = st.text_input("Max", value="", key="extra_max")
                extra_payload = {"variable": extra_var, "type": "num"}
                if str(extra_min).strip() != "":
                    extra_payload["min"] = float(extra_min)
                if str(extra_max).strip() != "":
                    extra_payload["max"] = float(extra_max)

        with addC:
            if st.button("➕", key="extra_add"):
                st.session_state["multi_obj_items"].append(extra_payload)
                st.rerun()

        if st.session_state["multi_obj_items"]:
            for i, it in enumerate(list(st.session_state["multi_obj_items"])):
                d1, d2 = st.columns([10, 1])
                d1.code(it, language="json")
                if d2.button("🗑️", key=f"extra_del_{i}"):
                    st.session_state["multi_obj_items"].pop(i)
                    st.rerun()

        items_final = [main_item] + list(st.session_state["multi_obj_items"])
        try:
            objectif_value_for_store = build_multi_objectif_json_for_ui(op, items_final)
            objectif_label_for_ui = objectif_value_for_store
        except Exception as e:
            st.warning(str(e))
            objectif_value_for_store = ""
            objectif_label_for_ui = ""

        # =====================================================
        # Blocs / Graphe
        # =====================================================
        blocks: List[Dict[str, Any]] = st.session_state["new_blocks"]
        visible = [b for b in blocks if b.get("Action") != "Closed"]

        if len(visible) == 1 and st.session_state["selected_bm"] is None:
            st.session_state["selected_bm"] = visible[0]["ID"]

        st.markdown("### Aperçu graphe (sans Closed)")
        selected_id = st.session_state["selected_bm"]
        if blocks:
            st.graphviz_chart(
                build_dot_from_liste_action(
                    blocks,
                    variable_cible,
                    objectif_label_for_ui if objectif_label_for_ui else (objectif_value_for_store or ""),
                    selected_id=selected_id,
                ),
                use_container_width=True,
            )
        else:
            st.info("Aucun bloc pour le moment.")

        # Sélection du bloc mère
        if visible:
            st.markdown("**Sélection du bloc mère**")
            per_row = 6
            for i in range(0, len(visible), per_row):
                row = visible[i : i + per_row]
                cols = st.columns(len(row))
                for col, b in zip(cols, row):
                    bid = b.get("ID")
                    canal_b = b.get("Canal", "")
                    label = f"✅ {canal_b}" if (selected_id is not None and bid == selected_id) else canal_b
                    with col:
                        if st.button(label, key=f"bm_{bid}"):
                            st.session_state["selected_bm"] = int(bid)
                            st.session_state.pop("cond_builder_conds", None)
                            st.session_state.pop("cond_builder_conds__init", None)
                            st.rerun()

        bloc_mere_dict = None
        if selected_id is not None:
            bloc_mere_dict = next((b for b in visible if b.get("ID") == selected_id), None)

        def _get_block_by_id(blocks_list: List[Dict[str, Any]], bid: int) -> Optional[Dict[str, Any]]:
            for bb in blocks_list:
                if bb.get("Action") == "Closed":
                    continue
                if bb.get("ID") == bid:
                    return bb
            return None

        def _get_parent_block(blocks_list: List[Dict[str, Any]], child: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            parent = str(child.get("Bloc_mère", "")).strip()
            if not parent.isdigit():
                return None
            return _get_block_by_id(blocks_list, int(parent))

        # Modifier conditions / contenu bloc sélectionné
        if selected_id is not None and blocks:
            selected_block = _get_block_by_id(blocks, int(selected_id))
            if selected_block is not None:
                parent_block = _get_parent_block(blocks, selected_block)

                if parent_block is not None:
                    with st.expander("🛠️ Modifier les conditions du bloc sélectionné", expanded=False):
                        existing_conds = selected_block.get("Conditions") or []
                        if not isinstance(existing_conds, list):
                            existing_conds = []

                        edit_prefix = f"edit_block_{int(selected_id)}"

                        edited_conds = render_condition_builder(
                            parent_block,
                            key_prefix=edit_prefix,
                            initial_conds=existing_conds,
                            show_existing=True,
                        )

                        cA, cB = st.columns([2, 2])
                        with cA:
                            if st.button("✅ Appliquer", key=f"{edit_prefix}_apply", use_container_width=True):
                                for bb in st.session_state["new_blocks"]:
                                    if bb.get("ID") == selected_block.get("ID"):
                                        bb["Conditions"] = edited_conds
                                        break
                                st.success("Conditions mises à jour ✅")
                                st.rerun()

                        with cB:
                            if st.button("↩️ Annuler", key=f"{edit_prefix}_cancel", use_container_width=True):
                                st.session_state.pop(f"{edit_prefix}_conds", None)
                                st.session_state.pop(f"{edit_prefix}_conds__init", None)
                                st.rerun()

                    with st.expander("✉️ Modifier le contenu du bloc sélectionné", expanded=False):
                        edit_txt_key = f"edit_txt_{int(selected_id)}"
                        edit_obj_key = f"edit_obj_{int(selected_id)}"
                        edit_init_key = f"edit_txt_init_{int(selected_id)}"

                        if not st.session_state.get(edit_init_key, False):
                            st.session_state[edit_txt_key] = str(selected_block.get("Contenu", "") or "")
                            st.session_state[edit_obj_key] = str(selected_block.get("Objet", "") or "")
                            st.session_state[edit_init_key] = True

                        canal_sel = str(selected_block.get("Canal", "") or "").strip()
                        new_obj = st.session_state.get(edit_obj_key, "")
                        if canal_sel == "Mail":
                            new_obj = st.text_input("Objet du mail", key=edit_obj_key)

                        new_txt = st.text_area("Contenu", height=160, key=edit_txt_key)

                        cX, cY = st.columns([2, 2])
                        with cX:
                            if st.button("✅ Appliquer (contenu/objet)", key=f"apply_txt_{int(selected_id)}", use_container_width=True):
                                for bb in st.session_state["new_blocks"]:
                                    if bb.get("Action") == "Closed":
                                        continue
                                    if bb.get("ID") == selected_block.get("ID"):
                                        bb["Contenu"] = new_txt
                                        bb["Objet"] = new_obj if canal_sel == "Mail" else ""
                                        break
                                st.success("Bloc mis à jour ✅")
                                st.rerun()

                        with cY:
                            if st.button("↩️ Annuler (contenu/objet)", key=f"cancel_txt_{int(selected_id)}", use_container_width=True):
                                st.session_state.pop(edit_txt_key, None)
                                st.session_state.pop(edit_obj_key, None)
                                st.session_state.pop(edit_init_key, None)
                                st.rerun()

        # Supprimer bloc sélectionné + descendants
        if bloc_mere_dict:
            if st.button("🗑️ Supprimer le bloc sélectionné (avec ses fils)"):
                target_id = int(bloc_mere_dict["ID"])
                ids_to_delete = set(_descendants_ids(visible, target_id))
                st.session_state["new_blocks"] = [b for b in blocks if int(b.get("ID")) not in ids_to_delete]

                remaining = [b for b in st.session_state["new_blocks"] if b.get("Action") != "Closed"]
                if not remaining:
                    st.session_state["selected_bm"] = None
                    st.session_state.pop("cond_builder_conds", None)
                    st.session_state.pop("cond_builder_conds__init", None)
                    st.rerun()

                pid = _parent_id_of(visible, target_id)
                st.session_state["selected_bm"] = (
                    pid if (pid is not None and any(b.get("ID") == pid for b in remaining)) else remaining[0]["ID"]
                )
                st.session_state.pop("cond_builder_conds", None)
                st.session_state.pop("cond_builder_conds__init", None)
                st.rerun()

        st.markdown("---")

        # Ajout nouveau bloc
        canal = st.selectbox("Canal du nouveau bloc", list_canaux())
        action = action_for_canal(canal)

        objet = ""
        if canal == "Mail":
            objet = st.text_input("Objet du mail", value="")

        contenu = st.text_area("Contenu", height=120, value="")

        conditions = []
        if blocks and bloc_mere_dict is not None:
            conditions = render_condition_builder(bloc_mere_dict, key_prefix="cond_builder", show_existing=False)

        c1, c2, c3 = st.columns([2, 2, 2])

        with c1:
            if st.button("➕ Ajouter le bloc"):
                parent = "" if not blocks else str(st.session_state["selected_bm"] or "")
                next_id = 1 if not blocks else (max(int(b.get("ID", 0)) for b in blocks) + 1)

                st.session_state["new_blocks"].append(
                    {
                        "ID": next_id,
                        "Bloc_mère": parent,
                        "Canal": canal,
                        "Action": action,
                        "Objet": objet if canal == "Mail" else "",
                        "Contenu": contenu,
                        "Conditions": conditions,
                    }
                )
                st.session_state["selected_bm"] = next_id
                st.session_state.pop("cond_builder_conds", None)
                st.session_state.pop("cond_builder_conds__init", None)
                st.rerun()

        with c2:
            if st.button("💾 Enregistrer le modèle", type="primary"):
                if not nom_modele:
                    st.error("Nom du modèle obligatoire.")
                    st.stop()

                if not objectif_value_for_store:
                    st.error("Objectif invalide / non renseigné.")
                    st.stop()

                try:
                    save_modele_for_ui(
                        is_editing=is_editing,
                        id_modele=str(st.session_state.get("edit_modele_id") or "").strip(),
                        nom_modele=nom_modele,
                        variable_cible=variable_cible,
                        objectif_value_for_store=objectif_value_for_store,
                        blocks=st.session_state["new_blocks"],
                    )
                    st.success("Modèle mis à jour ✅" if is_editing else "Modèle enregistré ✅")
                except Exception as e:
                    st.error(str(e))
                    st.stop()

                st.session_state["new_blocks"] = []
                st.session_state["selected_bm"] = None
                st.session_state.pop("cond_builder_conds", None)
                st.session_state.pop("cond_builder_conds__init", None)
                st.session_state.pop("multi_obj_items", None)
                _exit_edit_modele()
                st.session_state.create_mode = False
                st.rerun()

        with c3:
            if st.button("❌ Fermer"):
                st.session_state["new_blocks"] = []
                st.session_state["selected_bm"] = None
                st.session_state.pop("cond_builder_conds", None)
                st.session_state.pop("cond_builder_conds__init", None)
                st.session_state.pop("multi_obj_items", None)
                _exit_edit_modele()
                st.session_state.create_mode = False
                st.rerun()

        st.divider()

    # =====================================================
    # LIST
    # =====================================================
    rows = list_modeles_for_ui()
    st.subheader(f"Liste des modèles ({len(rows)})")

    if not rows:
        st.info("Aucun modèle.")
        return

    locked_modele_ids = get_locked_modele_ids_for_ui()

    for idx, r in enumerate(rows):
        mid = str(_pick(r, "ID_MODELE", "id_modele", "Id_modele", default="") or "").strip()
        nom = str(_pick(r, "Nom_modele", "nom_modele", "Nom_Modele", default="") or "").strip()
        is_locked = mid in locked_modele_ids if mid else False

        delete_key = f"del_{mid}" if mid else f"del_idx_{idx}"

        with st.container(border=True):
            a, b, c, d = st.columns([6, 1, 1, 1], vertical_alignment="center")

            a.write(f"**{mid if mid else '(sans id)'}** — {nom if nom else '(sans nom)'}")
            b.write(r.get("Date_creation", ""))

            if c.button("🗑️", key=delete_key, disabled=is_locked or (not mid)):
                delete_modele_for_ui(mid)
                st.rerun()

            if d.button("✏️", key=f"edit_{mid}", disabled=is_locked or (not mid)):
                _enter_edit_modele(mid)
                st.rerun()

            if is_locked:
                st.caption("🔒 Suppression / modification impossible (lié à campagne en cours/planifiée).")

            with st.expander("Détails"):
                varc = r.get("variable_cible", "")
                obj = r.get("Objectif", "")

                st.write("Colonne cible :", varc)
                st.write("Objectif :", objectif_label(varc, obj))

                actions = get_actions_from_row_for_ui(r)
                if actions:
                    st.markdown("**Aperçu graphe (sans Closed)**")
                    st.graphviz_chart(
                        build_dot_from_liste_action(actions, varc, objectif_label(varc, obj), selected_id=None),
                        use_container_width=True,
                    )
                else:
                    st.info("Aucune action.")


if __name__ == "__main__":
    main()
