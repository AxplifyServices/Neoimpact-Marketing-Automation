from __future__ import annotations

from typing import Any, Dict, List, Tuple

import streamlit as st

from app.engine.crc_engine import (
    get_ordered_rows_from_queue,
    move_row_to_end_of_queue,
    get_arrive_eche_flag,
    apply_result_and_update_client_campagnes,
    call_current_client,
    list_campaigns_in_crc_queue,  # ✅ NEW
    list_gestionnaires_in_queue,
    get_queue_counts_by_gestionnaire,
)
from app.domain.canaux import resultats_for_canal
from app.scripts.batch_manuel import run_batch_manuel

# ✅ façade UI : plus de sqlite3 / DB_PATH dans le front
from app.domain.ui_facades.crc_ui_facade import get_crc_context_from_db


def _render_header(ctx: Dict[str, Any]) -> None:
    nom_prenom = (" ".join([ctx.get("nom", ""), ctx.get("prenom", "")]).strip()) or "Client"
    st.markdown(f"### {nom_prenom}")

    c1, c2, c3, c4 = st.columns(4, vertical_alignment="center")
    with c1:
        st.caption("Campagne")
        st.write(ctx.get("nom_campagne") or "—")
    with c2:
        st.caption("Variable cible")
        var = ctx.get("variable_cible") or "—"
        val = ctx.get("valeur_cible") or ""
        st.write(f"{var}" + (f" : **{val}**" if val else ""))
    with c4:
        st.caption("Objectif")
        st.write(ctx.get("objectif") or "—")
    with c4:
        st.caption("État actuel")
        st.write(ctx.get("statut_actuel") or "—")

    st.divider()

def _gestionnaire_filter_ui(queue_table: str, key_prefix: str, id_campagne: str | None) -> str | None:
    gestionnaires = list_gestionnaires_in_queue(queue_table, id_campagne_filter=id_campagne)
    options = [("__ALL__", "Tous les gestionnaires")] + [(g, g) for g in gestionnaires]
    default_id = st.session_state.get(f"{key_prefix}_gest_filter", "__ALL__")
    default_index = next((i for i, (gid, _) in enumerate(options) if gid == default_id), 0)

    selected = st.selectbox(
        "Filtrer par gestionnaire",
        options=options,
        index=default_index,
        format_func=lambda x: x[1],
        key=f"{key_prefix}_gest_filter_select",
    )
    selected_id = selected[0]
    st.session_state[f"{key_prefix}_gest_filter"] = selected_id
    return None if selected_id == "__ALL__" else selected_id

def _campaign_filter_ui(key_prefix: str) -> str | None:
    campaigns: List[Tuple[str, str]] = list_campaigns_in_crc_queue()  # [(id, nom), ...]

    options = [("__ALL__", "Toutes les campagnes")]
    options += [(cid, f"{(cname or cid)}  ·  {cid}") for cid, cname in campaigns]

    default_id = st.session_state.get(f"{key_prefix}_camp_filter", "__ALL__")

    default_index = 0
    for i, (cid, _) in enumerate(options):
        if cid == default_id:
            default_index = i
            break

    selected = st.selectbox(
        "Filtrer par campagne",
        options=options,
        index=default_index,
        format_func=lambda x: x[1],
        key=f"{key_prefix}_camp_filter_select",
    )

    selected_id = selected[0]
    st.session_state[f"{key_prefix}_camp_filter"] = selected_id

    return None if selected_id == "__ALL__" else selected_id


def main(embedded: bool = False, key_prefix: str = "crc") -> None:
    if not embedded:
        st.title("📞 CRC")

    # Refresh = batch
    if not embedded:
        if st.button("🔄 Refresh", key=f"{key_prefix}_refresh"):
            run_batch_manuel()
            st.rerun()

    # ✅ Filtres (campagne -> gestionnaire)
    selected_campagne = _campaign_filter_ui(key_prefix=key_prefix)
    selected_gestionnaire = _gestionnaire_filter_ui("crc_input", key_prefix, selected_campagne)

    # ✅ Tableau counts par gestionnaire (optionnel)
    counts = get_queue_counts_by_gestionnaire("crc_input", id_campagne_filter=selected_campagne)
    if counts:
        st.caption("📌 Queue par gestionnaire")
        st.table(counts)

    # ✅ Rows filtrées (c’est CETTE liste qui pilote toute la page)
    rows = get_ordered_rows_from_queue(
        "crc_input",
        id_campagne_filter=selected_campagne,
        gestionnaire_filter=selected_gestionnaire,
    )

    state_key = f"{key_prefix}_current_key"
    cur_key = st.session_state.get(state_key)

    if cur_key:
        for i, r in enumerate(rows):
            if (
                str(r.get("ID_CAMPAGNE") or "").strip() == cur_key[0]
                and str(r.get("Radical_compte") or "").strip() == cur_key[1]
            ):
                current_idx = i
                break
        else:
            current_idx = 0
    else:
        current_idx = 0

    row = rows[current_idx] if rows else None
    if not row:
        if selected_campagne:
            st.info("Aucune ligne à traiter dans CRC pour la campagne sélectionnée.")
        else:
            st.info("Aucune ligne à traiter dans CRC.")
        st.session_state.pop(state_key, None)
        return

    id_campagne = str(row.get("ID_CAMPAGNE") or "").strip()
    radical = str(row.get("Radical_compte") or "").strip()
    st.session_state[state_key] = (id_campagne, radical)

    if get_arrive_eche_flag(id_campagne, radical):
        st.error("⚠️ Client arrivant à échéance")

    ctx = get_crc_context_from_db(id_campagne, radical)
    _render_header(ctx)

    canal = (row.get("Canal") or "").strip() or "Appel"
    resultats = resultats_for_canal(canal)

    c1, c2, c3, c4 = st.columns([0.16, 0.16, 0.16, 0.52], vertical_alignment="center")

    with c1:
        if st.button("⬅️ Reculer", key=f"{key_prefix}_back", use_container_width=True):
            if rows:
                prev_idx = (current_idx - 1) % len(rows)
                prev_row = rows[prev_idx]
                st.session_state[state_key] = (
                    str(prev_row.get("ID_CAMPAGNE") or "").strip(),
                    str(prev_row.get("Radical_compte") or "").strip(),
                )
            st.rerun()

    with c2:
        if st.button("Skip", key=f"{key_prefix}_skip", use_container_width=True):
            if rows:
                next_idx = (current_idx + 1) % len(rows)
                next_row = rows[next_idx]
                st.session_state[state_key] = (
                    str(next_row.get("ID_CAMPAGNE") or "").strip(),
                    str(next_row.get("Radical_compte") or "").strip(),
                )
            move_row_to_end_of_queue("crc_input", id_campagne, radical)
            st.rerun()

    with c4:
        if st.button("Appeler", key=f"{key_prefix}_call", use_container_width=True):
            call_current_client(row)
            st.rerun()

    with c4:
        if not resultats:
            st.warning("Aucun résultat défini pour ce canal.")
        else:
            cols = st.columns(len(resultats))
            for col, rlab in zip(cols, resultats):
                with col:
                    if st.button(rlab, key=f"{key_prefix}_res_{rlab}", use_container_width=True):
                        apply_result_and_update_client_campagnes(row, rlab)
                        st.rerun()
