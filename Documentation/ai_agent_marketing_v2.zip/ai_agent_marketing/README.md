# Agent IA Prédictif Bancaire — Marketing Automation

Agent IA on-premise qui calcule chaque nuit, pour chaque client :

- **Qui cibler ?** — score de propension ML (XGBoost / LightGBM) par produit.
- **Quoi proposer ?** — Next Best Action (`models/recommender.py`).
- **Quand & comment ?** — Send Time Optimization + routing multi-canal (Push, SMS, Email, Agence).
- **Sécurité & conformité** — filtres Bank Al-Maghrib (surendettement), CNDP/RGPD (consentement), anti-pression.

Le résultat est écrit dans la table `ai_customer_recommendations` de la base Marketing Automation (PostgreSQL), consommée ensuite par les campagnes.

## Architecture

```
ai_agent_marketing/
├── config/settings.py          # Config 12-factor + seuils de risque
├── data/
│   ├── extractors.py           # Connecteurs Data Lake (+ générateur synthétique)
│   └── loaders.py              # Ingestion PostgreSQL (COPY / execute_values + UPSERT)
├── models/
│   ├── propensity_model.py     # XGBoost + préprocesseur sklearn + SHAP
│   ├── recommender.py          # Next Best Action + fallback canal
│   └── timing.py               # STO (historique ou clustering KMeans)
├── rules/compliance.py         # BankComplianceEngine (BAM, CNDP, pression)
├── pipelines/daily_batch.py    # Orchestrateur (script cron OU DAG Airflow)
├── api/
│   ├── main.py                 # FastAPI : lecture temps réel + webhook CRM
│   └── schemas.py              # Contrats Pydantic
├── sql/                        # DDL + staging + UPSERT
└── tests/                      # pytest (conformité, fallback, perf batch)
```

## Démarrage rapide

```bash
cp .env.example .env            # renseigner les secrets
docker compose up --build       # Postgres + Redis + API (port 8000)
docker compose run --rm --profile batch batch   # lance le batch nocturne à la demande
```

Sans Docker :

```bash
pip install -r requirements.txt
export PYTHONPATH=$PWD
python -m pipelines.daily_batch     # exécute le pipeline (données synthétiques par défaut)
uvicorn api.main:app --reload       # API sur http://localhost:8000/docs
```

## Conformité (`rules/compliance.py`)

Le moteur applique, par ordre de priorité, des règles *fail-closed* :

1. **CNDP / Opt-In** — `has_cndp_consent == False` → `NO_CNDP_CONSENT`.
2. **BAM / Endettement** — produit de crédit avec `debt_ratio > 0.45` **ou** `has_bam_incident == True` → `OVERINDEBTEDNESS_RISK`.
3. **Pression commerciale** — `days_since_last_solicitation < 14` → `MAX_PRESSURE_REACHED`.

## Explicabilité

`PropensityPredictor` calcule les valeurs **SHAP** par prédiction ; `PredictionResult.top_reasons()` renvoie les features les plus contributrices, exploitables pour justifier chaque ciblage (audit / RGPD).

## Tests

```bash
pytest                          # tests unitaires (sans DB)
RUN_DB_TESTS=1 pytest -m integration   # tests d'intégration PostgreSQL
```

Scénarios couverts : exclusion risque (propension 0.95 + endettement 0.48), fallback canal Push→SMS, préparation batch 100 000 lignes < 60 s.

## Sécurité

100 % on-premise / cloud privé. Aucune PII n'est envoyée vers une API tierce externe (`ALLOW_EXTERNAL_PII_EGRESS=false`). Le webhook CRM cible exclusivement le CRM interne de la banque via un appel `httpx` sécurisé avec retries (`tenacity`).
