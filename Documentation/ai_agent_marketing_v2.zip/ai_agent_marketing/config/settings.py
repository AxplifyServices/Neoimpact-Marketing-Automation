"""
Configuration centrale de l'Agent IA prédictif bancaire.

Charge les variables d'environnement (12-factor) et expose des objets de
configuration typés et immuables. Aucune valeur PII ni secret n'est codée en
dur : tout provient de l'environnement ou d'un fichier `.env` (voir
`.env.example`).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Final

try:
    # Optionnel : charge automatiquement un fichier .env s'il est présent.
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover - dépendance optionnelle
    pass


def _get_bool(key: str, default: bool = False) -> bool:
    return os.getenv(key, str(default)).strip().lower() in {"1", "true", "yes", "on"}


def _get_float(key: str, default: float) -> float:
    try:
        return float(os.getenv(key, str(default)))
    except (TypeError, ValueError):
        return default


def _get_int(key: str, default: int) -> int:
    try:
        return int(os.getenv(key, str(default)))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class DatabaseSettings:
    """Connexion PostgreSQL cible (Marketing Automation)."""

    host: str = field(default_factory=lambda: os.getenv("DB_HOST", "localhost"))
    port: int = field(default_factory=lambda: _get_int("DB_PORT", 5432))
    name: str = field(default_factory=lambda: os.getenv("DB_NAME", "marketing_automation"))
    user: str = field(default_factory=lambda: os.getenv("DB_USER", "postgres"))
    password: str = field(default_factory=lambda: os.getenv("DB_PASSWORD", "postgres"))
    schema: str = field(default_factory=lambda: os.getenv("DB_SCHEMA", "public"))
    min_pool: int = field(default_factory=lambda: _get_int("DB_MIN_POOL", 1))
    max_pool: int = field(default_factory=lambda: _get_int("DB_MAX_POOL", 10))

    @property
    def dsn(self) -> str:
        """DSN psycopg2 (libpq)."""
        return (
            f"host={self.host} port={self.port} dbname={self.name} "
            f"user={self.user} password={self.password}"
        )

    @property
    def sqlalchemy_url(self) -> str:
        return (
            f"postgresql+psycopg2://{self.user}:{self.password}"
            f"@{self.host}:{self.port}/{self.name}"
        )


@dataclass(frozen=True)
class RiskThresholds:
    """Seuils métier / conformité (Bank Al-Maghrib, pression commerciale)."""

    # Taux d'endettement maximal toléré pour un produit de crédit (BAM).
    max_debt_ratio: float = field(default_factory=lambda: _get_float("MAX_DEBT_RATIO", 0.45))
    # Fenêtre anti-pression : nombre de jours minimum entre deux sollicitations.
    min_days_between_solicitations: int = field(
        default_factory=lambda: _get_int("MIN_DAYS_BETWEEN_SOLICITATIONS", 14)
    )
    # Score de propension minimal pour restituer une recommandation.
    min_propensity_score: float = field(
        default_factory=lambda: _get_float("MIN_PROPENSITY_SCORE", 0.30)
    )


@dataclass(frozen=True)
class ModelSettings:
    """Paramètres du modèle ML et versionning."""

    model_version: str = field(default_factory=lambda: os.getenv("MODEL_VERSION", "v1.0.0"))
    artifacts_dir: str = field(default_factory=lambda: os.getenv("MODEL_ARTIFACTS_DIR", "./artifacts"))
    random_state: int = field(default_factory=lambda: _get_int("MODEL_RANDOM_STATE", 42))
    n_estimators: int = field(default_factory=lambda: _get_int("MODEL_N_ESTIMATORS", 300))
    max_depth: int = field(default_factory=lambda: _get_int("MODEL_MAX_DEPTH", 6))
    learning_rate: float = field(default_factory=lambda: _get_float("MODEL_LEARNING_RATE", 0.05))
    enable_shap: bool = field(default_factory=lambda: _get_bool("MODEL_ENABLE_SHAP", True))


@dataclass(frozen=True)
class CRMSettings:
    """Connexion sécurisée vers le CRM Agence de la banque."""

    base_url: str = field(default_factory=lambda: os.getenv("CRM_BASE_URL", "https://crm.internal.bank/api"))
    api_key: str = field(default_factory=lambda: os.getenv("CRM_API_KEY", ""))
    timeout_seconds: float = field(default_factory=lambda: _get_float("CRM_TIMEOUT_SECONDS", 10.0))
    max_retries: int = field(default_factory=lambda: _get_int("CRM_MAX_RETRIES", 3))
    verify_ssl: bool = field(default_factory=lambda: _get_bool("CRM_VERIFY_SSL", True))


@dataclass(frozen=True)
class Settings:
    """Agrégat de configuration exposé au reste de l'application."""

    database: DatabaseSettings = field(default_factory=DatabaseSettings)
    risk: RiskThresholds = field(default_factory=RiskThresholds)
    model: ModelSettings = field(default_factory=ModelSettings)
    crm: CRMSettings = field(default_factory=CRMSettings)

    # 100% on-premise : aucun envoi de PII vers une API tierce externe.
    allow_external_pii_egress: bool = field(
        default_factory=lambda: _get_bool("ALLOW_EXTERNAL_PII_EGRESS", False)
    )
    batch_target_seconds: int = field(default_factory=lambda: _get_int("BATCH_TARGET_SECONDS", 60))
    batch_chunk_size: int = field(default_factory=lambda: _get_int("BATCH_CHUNK_SIZE", 10_000))


# Canaux et créneaux normalisés (référentiel unique partagé par les modules).
CHANNELS: Final[tuple[str, ...]] = ("PUSH_APP", "SMS", "EMAIL", "AGENCY_CALL")
TIME_SLOTS: Final[tuple[str, ...]] = ("MORNING_09H", "AFTERNOON_14H", "EVENING_20H")
WEEKDAYS: Final[tuple[str, ...]] = (
    "MONDAY",
    "TUESDAY",
    "WEDNESDAY",
    "THURSDAY",
    "FRIDAY",
    "SATURDAY",
    "SUNDAY",
)
CREDIT_PRODUCTS: Final[frozenset[str]] = frozenset(
    {"CREDIT_CONSO", "CREDIT_IMMO", "CARTE_GOLD", "CREDIT_AUTO"}
)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Retourne l'instance unique (singleton) de configuration."""
    return Settings()
