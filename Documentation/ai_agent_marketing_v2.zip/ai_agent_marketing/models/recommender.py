"""
Moteur Next Best Action (models/recommender.py).

À partir d'une matrice de scores de propension par produit (une colonne par
produit candidat), sélectionne pour chaque client :
  - le produit à la propension maximale (Next Best Action),
  - le canal recommandé (avec logique de fallback token Push -> SMS),
  - au-dessus du seuil minimal de propension configuré.

Le routing multi-canal est déterministe et testable ; la logique de fallback
est isolée dans `resolve_channel` pour être couverte unitairement.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
import pandas as pd

from config.settings import get_settings

logger = logging.getLogger(__name__)

# Canal préféré par produit (avant application des règles de fallback).
_PREFERRED_CHANNEL: dict[str, str] = {
    "CREDIT_CONSO": "AGENCY_CALL",
    "CREDIT_IMMO": "AGENCY_CALL",
    "CREDIT_AUTO": "AGENCY_CALL",
    "CARTE_GOLD": "PUSH_APP",
    "EPARGNE_LIVRET": "PUSH_APP",
    "ASSURANCE_VIE": "EMAIL",
}
_DEFAULT_CHANNEL = "SMS"


def resolve_channel(
    product: str,
    has_valid_push_token: bool,
    has_email: bool = True,
    has_mobile: bool = True,
) -> str:
    """
    Résout le canal effectif avec règles de fallback.

    - Canal préféré PUSH_APP mais token invalide/inexistant -> SMS.
    - Canal SMS sans mobile connu -> EMAIL.
    - Canal EMAIL sans email connu -> SMS.
    """
    channel = _PREFERRED_CHANNEL.get(product, _DEFAULT_CHANNEL)

    if channel == "PUSH_APP" and not has_valid_push_token:
        channel = "SMS"
    if channel == "SMS" and not has_mobile:
        channel = "EMAIL"
    if channel == "EMAIL" and not has_email:
        channel = "SMS"
    return channel


@dataclass
class NextBestActionResult:
    """Sortie NBA par client."""

    frame: pd.DataFrame  # colonnes: client_id, next_best_action, propensity_score, recommended_channel


class NextBestActionRecommender:
    """Sélectionne la meilleure offre et le canal pour chaque client."""

    def __init__(self, min_score: float | None = None) -> None:
        self.min_score = (
            min_score if min_score is not None else get_settings().risk.min_propensity_score
        )

    def recommend(
        self,
        propensity_matrix: pd.DataFrame,
        contactability: pd.DataFrame | None = None,
    ) -> NextBestActionResult:
        """
        Args:
            propensity_matrix: index = client_id, une colonne par produit, valeurs = score [0,1].
            contactability: colonnes optionnelles client_id, has_valid_push_token,
                has_email, has_mobile. Défauts conservateurs si absent.
        """
        if propensity_matrix.empty:
            empty = pd.DataFrame(
                columns=["client_id", "next_best_action", "propensity_score", "recommended_channel"]
            )
            return NextBestActionResult(frame=empty)

        best_product = propensity_matrix.idxmax(axis=1)
        best_score = propensity_matrix.max(axis=1)

        out = pd.DataFrame(
            {
                "client_id": propensity_matrix.index.astype(str),
                "next_best_action": best_product.values,
                "propensity_score": np.round(best_score.values.astype(float), 4),
            }
        )

        contact = self._prepare_contactability(out["client_id"], contactability)
        merged = out.merge(contact, on="client_id", how="left")

        merged["recommended_channel"] = [
            resolve_channel(
                product=row.next_best_action,
                has_valid_push_token=bool(row.has_valid_push_token),
                has_email=bool(row.has_email),
                has_mobile=bool(row.has_mobile),
            )
            for row in merged.itertuples(index=False)
        ]

        # Filtrage par seuil minimal de propension.
        below = merged["propensity_score"] < self.min_score
        if below.any():
            logger.info("%s clients sous le seuil de propension (%.2f)", int(below.sum()), self.min_score)

        result = merged[
            ["client_id", "next_best_action", "propensity_score", "recommended_channel"]
        ].copy()
        result["_below_threshold"] = below.values
        return NextBestActionResult(frame=result)

    @staticmethod
    def _prepare_contactability(
        client_ids: pd.Series, contactability: pd.DataFrame | None
    ) -> pd.DataFrame:
        base = pd.DataFrame({"client_id": client_ids.astype(str)})
        if contactability is None:
            base["has_valid_push_token"] = False
            base["has_email"] = True
            base["has_mobile"] = True
            return base

        c = contactability.copy()
        c["client_id"] = c["client_id"].astype(str)
        for col, default in (
            ("has_valid_push_token", False),
            ("has_email", True),
            ("has_mobile", True),
        ):
            if col not in c.columns:
                c[col] = default
        return base.merge(
            c[["client_id", "has_valid_push_token", "has_email", "has_mobile"]],
            on="client_id",
            how="left",
        ).fillna({"has_valid_push_token": False, "has_email": True, "has_mobile": True})
