"""
Send Time Optimization (models/timing.py).

Détermine le créneau horaire et le jour optimaux par client à partir de son
historique d'engagement. Deux stratégies :
  - historique disponible : argmax de l'engagement observé par (jour, créneau),
  - historique absent : clustering KMeans sur des features comportementales
    pour affecter un profil de créneau par défaut.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

from config.settings import TIME_SLOTS, WEEKDAYS, get_settings

logger = logging.getLogger(__name__)

# Mapping cluster -> créneau par défaut (profils comportementaux).
_CLUSTER_TO_SLOT = {0: "MORNING_09H", 1: "AFTERNOON_14H", 2: "EVENING_20H"}
_CLUSTER_TO_DAY = {0: "TUESDAY", 1: "THURSDAY", 2: "WEDNESDAY"}


@dataclass
class TimingResult:
    frame: pd.DataFrame  # colonnes: client_id, optimal_time_slot, optimal_day


class SendTimeOptimizer:
    """Calcule le meilleur (jour, créneau) d'envoi par client."""

    def __init__(self, n_clusters: int = 3, random_state: int | None = None) -> None:
        self.n_clusters = n_clusters
        self.random_state = (
            random_state if random_state is not None else get_settings().model.random_state
        )
        self._model: KMeans | None = None

    def optimize(
        self,
        engagement_history: pd.DataFrame | None = None,
        behavioral_features: pd.DataFrame | None = None,
    ) -> TimingResult:
        """
        Args:
            engagement_history: colonnes client_id, day, time_slot, engagement_count.
                Si fourni, prioritaire : on prend le (day, slot) à engagement max.
            behavioral_features: index/col client_id + features numériques pour KMeans
                (repli quand pas d'historique).
        """
        if engagement_history is not None and not engagement_history.empty:
            return self._from_history(engagement_history)
        if behavioral_features is not None and not behavioral_features.empty:
            return self._from_clustering(behavioral_features)
        raise ValueError("Fournir engagement_history OU behavioral_features.")

    # ------------------------------------------------------------------ #
    def _from_history(self, hist: pd.DataFrame) -> TimingResult:
        hist = hist.copy()
        hist["client_id"] = hist["client_id"].astype(str)
        # Ligne à engagement maximal par client.
        idx = hist.groupby("client_id")["engagement_count"].idxmax()
        best = hist.loc[idx, ["client_id", "day", "time_slot"]].reset_index(drop=True)

        best["optimal_day"] = best["day"].where(best["day"].isin(WEEKDAYS), "TUESDAY")
        best["optimal_time_slot"] = best["time_slot"].where(
            best["time_slot"].isin(TIME_SLOTS), "AFTERNOON_14H"
        )
        logger.info("STO calculé depuis l'historique pour %s clients", len(best))
        return TimingResult(frame=best[["client_id", "optimal_time_slot", "optimal_day"]])

    def _from_clustering(self, feats: pd.DataFrame) -> TimingResult:
        feats = feats.copy()
        client_ids = feats["client_id"].astype(str) if "client_id" in feats else feats.index.astype(str)
        numeric = feats.drop(columns=["client_id"], errors="ignore").select_dtypes("number")
        numeric = numeric.fillna(numeric.median(numeric_only=True))

        n_clusters = min(self.n_clusters, max(1, len(numeric)))
        self._model = KMeans(n_clusters=n_clusters, random_state=self.random_state, n_init=10)
        labels = self._model.fit_predict(numeric.values)

        out = pd.DataFrame(
            {
                "client_id": np.asarray(client_ids),
                "optimal_time_slot": [_CLUSTER_TO_SLOT.get(int(l) % 3, "AFTERNOON_14H") for l in labels],
                "optimal_day": [_CLUSTER_TO_DAY.get(int(l) % 3, "TUESDAY") for l in labels],
            }
        )
        logger.info("STO calculé par clustering (%s clusters) pour %s clients", n_clusters, len(out))
        return TimingResult(frame=out)
