"""
Modèle de propension (models/propensity_model.py).

Pipeline scikit-learn complet :
  - préprocesseur (Imputer + StandardScaler numérique, OneHotEncoder catégoriel)
  - classifieur XGBoost (fallback GradientBoosting si xgboost indisponible)
  - explicabilité SHAP par prédiction

Le modèle est sérialisable (joblib) et versionné via config.model.model_version.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Sequence

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from config.settings import ModelSettings, get_settings

logger = logging.getLogger(__name__)

# --- Import XGBoost avec repli gracieux -----------------------------------
try:
    from xgboost import XGBClassifier

    _HAS_XGBOOST = True
except ImportError:  # pragma: no cover
    from sklearn.ensemble import GradientBoostingClassifier

    _HAS_XGBOOST = False
    logger.warning("xgboost indisponible -> repli sur GradientBoostingClassifier.")

# --- Import SHAP avec repli gracieux --------------------------------------
try:
    import shap

    _HAS_SHAP = True
except ImportError:  # pragma: no cover
    _HAS_SHAP = False
    logger.warning("shap indisponible -> l'explicabilité sera désactivée.")


@dataclass
class PredictionResult:
    """Résultat d'inférence pour un batch de clients."""

    client_ids: Sequence[str]
    scores: np.ndarray                       # propension P(classe=1), shape (n,)
    shap_values: np.ndarray | None = None    # shape (n, n_features) ou None
    feature_names: list[str] = field(default_factory=list)

    def top_reasons(self, top_k: int = 3) -> list[list[tuple[str, float]]]:
        """Retourne les `top_k` features les plus contributrices par client."""
        if self.shap_values is None or not self.feature_names:
            return [[] for _ in self.client_ids]
        reasons: list[list[tuple[str, float]]] = []
        for row in self.shap_values:
            order = np.argsort(np.abs(row))[::-1][:top_k]
            reasons.append([(self.feature_names[i], float(row[i])) for i in order])
        return reasons


class PropensityPredictor:
    """Entraînement, inférence et explicabilité du score de propension."""

    def __init__(
        self,
        numeric_features: Sequence[str],
        categorical_features: Sequence[str],
        settings: ModelSettings | None = None,
    ) -> None:
        self.numeric_features = list(numeric_features)
        self.categorical_features = list(categorical_features)
        self.settings = settings or get_settings().model
        self.pipeline: Pipeline | None = None
        self._explainer = None  # shap.TreeExplainer, initialisé après fit

    # ------------------------------------------------------------------ #
    # Construction
    # ------------------------------------------------------------------ #
    def _build_preprocessor(self) -> ColumnTransformer:
        numeric = Pipeline(
            steps=[
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
            ]
        )
        categorical = Pipeline(
            steps=[
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore")),
            ]
        )
        return ColumnTransformer(
            transformers=[
                ("num", numeric, self.numeric_features),
                ("cat", categorical, self.categorical_features),
            ],
            remainder="drop",
        )

    def _build_classifier(self):
        if _HAS_XGBOOST:
            return XGBClassifier(
                n_estimators=self.settings.n_estimators,
                max_depth=self.settings.max_depth,
                learning_rate=self.settings.learning_rate,
                subsample=0.9,
                colsample_bytree=0.9,
                objective="binary:logistic",
                eval_metric="auc",
                random_state=self.settings.random_state,
                n_jobs=-1,
                tree_method="hist",
            )
        return GradientBoostingClassifier(  # type: ignore[name-defined]
            n_estimators=self.settings.n_estimators,
            max_depth=self.settings.max_depth,
            learning_rate=self.settings.learning_rate,
            random_state=self.settings.random_state,
        )

    # ------------------------------------------------------------------ #
    # Entraînement
    # ------------------------------------------------------------------ #
    def fit(self, X: pd.DataFrame, y: Sequence[int]) -> "PropensityPredictor":
        """Entraîne le pipeline complet (préprocesseur + classifieur)."""
        self.pipeline = Pipeline(
            steps=[
                ("preprocessor", self._build_preprocessor()),
                ("classifier", self._build_classifier()),
            ]
        )
        self.pipeline.fit(X, np.asarray(y))
        logger.info("Modèle entraîné (%s features num, %s cat) version=%s",
                    len(self.numeric_features), len(self.categorical_features),
                    self.settings.model_version)

        if self.settings.enable_shap and _HAS_SHAP:
            try:
                model = self.pipeline.named_steps["classifier"]
                self._explainer = shap.TreeExplainer(model)
            except Exception as exc:  # pragma: no cover - dépend de la lib
                logger.warning("Initialisation SHAP échouée: %s", exc)
                self._explainer = None
        return self

    # ------------------------------------------------------------------ #
    # Inférence
    # ------------------------------------------------------------------ #
    def predict(self, X: pd.DataFrame, client_ids: Sequence[str]) -> PredictionResult:
        """Calcule le score de propension et (si possible) les valeurs SHAP."""
        if self.pipeline is None:
            raise RuntimeError("Le modèle n'est pas entraîné : appeler fit() d'abord.")

        proba = self.pipeline.predict_proba(X)[:, 1]

        shap_values: np.ndarray | None = None
        feature_names: list[str] = []
        if self._explainer is not None:
            try:
                pre = self.pipeline.named_steps["preprocessor"]
                X_trans = pre.transform(X)
                feature_names = list(pre.get_feature_names_out())
                raw = self._explainer.shap_values(X_trans)
                # XGBoost binaire -> ndarray ; certaines versions -> liste [neg, pos]
                shap_values = raw[1] if isinstance(raw, list) else raw
            except Exception as exc:  # pragma: no cover
                logger.warning("Calcul SHAP échoué: %s", exc)

        return PredictionResult(
            client_ids=list(client_ids),
            scores=np.round(proba, 4),
            shap_values=shap_values,
            feature_names=feature_names,
        )

    # ------------------------------------------------------------------ #
    # Persistance
    # ------------------------------------------------------------------ #
    def save(self, path: str | None = None) -> str:
        import joblib

        os.makedirs(self.settings.artifacts_dir, exist_ok=True)
        target = path or os.path.join(
            self.settings.artifacts_dir, f"propensity_{self.settings.model_version}.joblib"
        )
        joblib.dump(
            {
                "pipeline": self.pipeline,
                "numeric_features": self.numeric_features,
                "categorical_features": self.categorical_features,
                "model_version": self.settings.model_version,
            },
            target,
        )
        logger.info("Modèle sauvegardé -> %s", target)
        return target

    @classmethod
    def load(cls, path: str, settings: ModelSettings | None = None) -> "PropensityPredictor":
        import joblib

        blob = joblib.load(path)
        instance = cls(
            numeric_features=blob["numeric_features"],
            categorical_features=blob["categorical_features"],
            settings=settings,
        )
        instance.pipeline = blob["pipeline"]
        if instance.settings.enable_shap and _HAS_SHAP:
            try:
                instance._explainer = shap.TreeExplainer(
                    instance.pipeline.named_steps["classifier"]
                )
            except Exception:  # pragma: no cover
                instance._explainer = None
        return instance
