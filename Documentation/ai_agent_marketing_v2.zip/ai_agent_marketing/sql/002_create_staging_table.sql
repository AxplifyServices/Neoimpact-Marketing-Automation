--liquibase formatted sql
--changeset ai_agent:002_create_staging_table

-- ==========================================================================
-- Table de staging (UNLOGGED pour la vitesse) alimentée par COPY / execute_values
-- puis fusionnée dans la table cible via un UPSERT atomique (voir loaders.py).
-- ==========================================================================
CREATE UNLOGGED TABLE IF NOT EXISTS ai_customer_recommendations_staging (
    client_id           VARCHAR(50)   NOT NULL,
    next_best_action    VARCHAR(50)   NOT NULL,
    propensity_score    DECIMAL(5, 4) NOT NULL,
    recommended_channel VARCHAR(20)   NOT NULL,
    optimal_time_slot   VARCHAR(20)   NOT NULL,
    optimal_day         VARCHAR(10)   NOT NULL,
    eligibility_status  BOOLEAN       NOT NULL DEFAULT TRUE,
    exclusion_reason    VARCHAR(100),
    model_version       VARCHAR(20)   NOT NULL
);

TRUNCATE TABLE ai_customer_recommendations_staging;

--rollback DROP TABLE IF EXISTS ai_customer_recommendations_staging;
