--liquibase formatted sql
--changeset ai_agent:003_upsert_from_staging runOnChange:true

-- ==========================================================================
-- DML d'UPSERT : fusionne le staging dans la table cible en une seule
-- instruction set-based (bien plus rapide que des UPDATE ligne à ligne).
-- ==========================================================================
INSERT INTO ai_customer_recommendations AS tgt (
    client_id, next_best_action, propensity_score, recommended_channel,
    optimal_time_slot, optimal_day, eligibility_status, exclusion_reason,
    model_version, updated_at
)
SELECT
    client_id, next_best_action, propensity_score, recommended_channel,
    optimal_time_slot, optimal_day, eligibility_status, exclusion_reason,
    model_version, CURRENT_TIMESTAMP
FROM ai_customer_recommendations_staging
ON CONFLICT (client_id) DO UPDATE SET
    next_best_action    = EXCLUDED.next_best_action,
    propensity_score    = EXCLUDED.propensity_score,
    recommended_channel = EXCLUDED.recommended_channel,
    optimal_time_slot   = EXCLUDED.optimal_time_slot,
    optimal_day         = EXCLUDED.optimal_day,
    eligibility_status  = EXCLUDED.eligibility_status,
    exclusion_reason    = EXCLUDED.exclusion_reason,
    model_version       = EXCLUDED.model_version,
    updated_at          = CURRENT_TIMESTAMP;
