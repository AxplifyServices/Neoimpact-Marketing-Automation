--liquibase formatted sql
--changeset ai_agent:001_create_ai_customer_recommendations

-- ==========================================================================
-- Table de restitution IA — consommée par le moteur de Marketing Automation.
-- Une ligne = la meilleure action next-best pour un client à une date donnée.
-- ==========================================================================
CREATE TABLE IF NOT EXISTS ai_customer_recommendations (
    client_id           VARCHAR(50)   PRIMARY KEY,
    next_best_action    VARCHAR(50)   NOT NULL,          -- 'CREDIT_CONSO', 'CARTE_GOLD', 'EPARGNE_LIVRET'
    propensity_score    DECIMAL(5, 4) NOT NULL,          -- 0.0000 -> 1.0000
    recommended_channel VARCHAR(20)   NOT NULL,          -- 'PUSH_APP', 'SMS', 'EMAIL', 'AGENCY_CALL'
    optimal_time_slot   VARCHAR(20)   NOT NULL,          -- 'MORNING_09H', 'AFTERNOON_14H', 'EVENING_20H'
    optimal_day         VARCHAR(10)   NOT NULL,          -- 'MONDAY', 'TUESDAY', ...
    eligibility_status  BOOLEAN       DEFAULT TRUE,
    exclusion_reason    VARCHAR(100),                    -- 'OVERINDEBTEDNESS_RISK', 'NO_CNDP_CONSENT', 'MAX_PRESSURE_REACHED'
    model_version       VARCHAR(20)   NOT NULL,
    created_at          TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_propensity_range CHECK (propensity_score >= 0 AND propensity_score <= 1),
    CONSTRAINT chk_channel CHECK (recommended_channel IN ('PUSH_APP', 'SMS', 'EMAIL', 'AGENCY_CALL'))
);

CREATE INDEX IF NOT EXISTS idx_ai_rec_lookup
    ON ai_customer_recommendations (next_best_action, propensity_score, recommended_channel);

CREATE INDEX IF NOT EXISTS idx_ai_eligibility
    ON ai_customer_recommendations (eligibility_status, next_best_action);

-- Trigger de mise à jour automatique de updated_at.
CREATE OR REPLACE FUNCTION trg_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_updated_at ON ai_customer_recommendations;
CREATE TRIGGER set_updated_at
    BEFORE UPDATE ON ai_customer_recommendations
    FOR EACH ROW EXECUTE FUNCTION trg_set_updated_at();

--rollback DROP TABLE IF EXISTS ai_customer_recommendations CASCADE;
