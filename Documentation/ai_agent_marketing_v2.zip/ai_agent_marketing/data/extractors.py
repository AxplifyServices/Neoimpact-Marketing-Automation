"""
Extracteurs de données (data/extractors.py).

Connecteurs en lecture vers le Data Lake / entrepôt on-premise. L'accès réel
se fait via SQLAlchemy (PostgreSQL, Redshift, etc.). Une implémentation de
secours génère un jeu de données synthétique pour les tests et démos, sans
jamais faire transiter de PII vers l'extérieur.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod

import numpy as np
import pandas as pd

from config.settings import CREDIT_PRODUCTS, Settings, get_settings

logger = logging.getLogger(__name__)

# Produits candidats évalués par le moteur NBA.
CANDIDATE_PRODUCTS: tuple[str, ...] = (
    "CREDIT_CONSO",
    "CARTE_GOLD",
    "EPARGNE_LIVRET",
    "ASSURANCE_VIE",
    "CREDIT_IMMO",
)

NUMERIC_FEATURES: tuple[str, ...] = (
    "age",
    "tenure_months",
    "monthly_income",
    "avg_balance",
    "debt_ratio",
    "n_products_held",
    "days_since_last_solicitation",
    "web_sessions_30d",
)
CATEGORICAL_FEATURES: tuple[str, ...] = ("segment", "region", "channel_pref")


class BaseExtractor(ABC):
    """Contrat d'un extracteur de features clients."""

    @abstractmethod
    def extract_customer_features(self) -> pd.DataFrame: ...

    @abstractmethod
    def extract_engagement_history(self) -> pd.DataFrame: ...

    @abstractmethod
    def extract_contactability(self) -> pd.DataFrame: ...


class SQLDataLakeExtractor(BaseExtractor):
    """Extraction depuis une source SQL (SQLAlchemy Engine)."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self._engine = None

    @property
    def engine(self):
        if self._engine is None:
            from sqlalchemy import create_engine

            self._engine = create_engine(
                self.settings.database.sqlalchemy_url,
                pool_size=self.settings.database.max_pool,
                pool_pre_ping=True,
            )
        return self._engine

    def extract_customer_features(self) -> pd.DataFrame:
        query = """
            SELECT client_id, age, tenure_months, monthly_income, avg_balance,
                   debt_ratio, n_products_held, days_since_last_solicitation,
                   web_sessions_30d, segment, region, channel_pref,
                   has_cndp_consent, has_bam_incident
            FROM data_lake.customer_360
        """
        logger.info("Extraction customer_360 depuis la source SQL...")
        return pd.read_sql(query, self.engine)

    def extract_engagement_history(self) -> pd.DataFrame:
        query = """
            SELECT client_id, day, time_slot, SUM(engagement) AS engagement_count
            FROM data_lake.engagement_events
            GROUP BY client_id, day, time_slot
        """
        return pd.read_sql(query, self.engine)

    def extract_contactability(self) -> pd.DataFrame:
        query = """
            SELECT client_id, has_valid_push_token, has_email, has_mobile
            FROM data_lake.contactability
        """
        return pd.read_sql(query, self.engine)


class SyntheticExtractor(BaseExtractor):
    """Générateur de données synthétiques (tests / démo hors production)."""

    def __init__(self, n_customers: int = 1_000, seed: int = 42) -> None:
        self.n_customers = n_customers
        self.rng = np.random.default_rng(seed)

    def _client_ids(self) -> np.ndarray:
        return np.array([f"CLI{idx:07d}" for idx in range(self.n_customers)])

    def extract_customer_features(self) -> pd.DataFrame:
        n = self.n_customers
        rng = self.rng
        df = pd.DataFrame(
            {
                "client_id": self._client_ids(),
                "age": rng.integers(18, 80, n),
                "tenure_months": rng.integers(1, 300, n),
                "monthly_income": rng.normal(9000, 4000, n).clip(2000, 60000).round(2),
                "avg_balance": rng.normal(15000, 12000, n).clip(0, None).round(2),
                "debt_ratio": rng.beta(2, 5, n).round(4),
                "n_products_held": rng.integers(1, 8, n),
                "days_since_last_solicitation": rng.integers(0, 120, n),
                "web_sessions_30d": rng.poisson(6, n),
                "segment": rng.choice(["MASS", "AFFLUENT", "PREMIUM", "YOUNG"], n),
                "region": rng.choice(["CASA", "RABAT", "MARRAKECH", "TANGER", "FES"], n),
                "channel_pref": rng.choice(["PUSH_APP", "SMS", "EMAIL", "AGENCY_CALL"], n),
                "has_cndp_consent": rng.random(n) > 0.15,
                "has_bam_incident": rng.random(n) < 0.08,
            }
        )
        return df

    def extract_engagement_history(self) -> pd.DataFrame:
        from config.settings import TIME_SLOTS, WEEKDAYS

        rows = []
        for cid in self._client_ids():
            for day in self.rng.choice(WEEKDAYS, 2, replace=False):
                for slot in TIME_SLOTS:
                    rows.append((cid, day, slot, int(self.rng.integers(0, 20))))
        return pd.DataFrame(rows, columns=["client_id", "day", "time_slot", "engagement_count"])

    def extract_contactability(self) -> pd.DataFrame:
        n = self.n_customers
        return pd.DataFrame(
            {
                "client_id": self._client_ids(),
                "has_valid_push_token": self.rng.random(n) > 0.4,
                "has_email": self.rng.random(n) > 0.1,
                "has_mobile": self.rng.random(n) > 0.05,
            }
        )

    def build_training_labels(self, features: pd.DataFrame) -> pd.Series:
        """Génère une cible binaire corrélée aux features (démo d'entraînement)."""
        logit = (
            0.00004 * (features["monthly_income"] - 9000)
            - 3.0 * (features["debt_ratio"] - 0.3)
            + 0.05 * (features["web_sessions_30d"] - 6)
        )
        proba = 1 / (1 + np.exp(-logit))
        return (self.rng.random(len(features)) < proba).astype(int)


def get_default_extractor() -> BaseExtractor:
    """Fabrique l'extracteur adapté à l'environnement courant."""
    settings = get_settings()
    if settings.database.host and settings.database.password not in {"", "postgres"}:
        return SQLDataLakeExtractor(settings)
    logger.warning("Extracteur synthétique actif (aucune source SQL configurée).")
    return SyntheticExtractor()
