"""
Chargeur haute performance (data/loaders.py).

Ingère les recommandations IA dans PostgreSQL en garantissant le traitement de
100 000 lignes en moins de 60 secondes. Deux stratégies :
  - COPY via un buffer CSV en mémoire (la plus rapide),
  - psycopg2.extras.execute_values (repli, toujours set-based).

Le flux est : TRUNCATE staging -> chargement en masse -> UPSERT set-based
depuis le staging vers la table cible (idempotent, atomique).
"""
from __future__ import annotations

import csv
import io
import logging
import time
from typing import Iterable, Sequence

import pandas as pd
import psycopg2
from psycopg2 import extras

from config.settings import Settings, get_settings

logger = logging.getLogger(__name__)

TARGET_TABLE = "ai_customer_recommendations"
STAGING_TABLE = "ai_customer_recommendations_staging"

COLUMNS: tuple[str, ...] = (
    "client_id",
    "next_best_action",
    "propensity_score",
    "recommended_channel",
    "optimal_time_slot",
    "optimal_day",
    "eligibility_status",
    "exclusion_reason",
    "model_version",
)

_UPSERT_SQL = f"""
INSERT INTO {TARGET_TABLE} AS tgt (
    {", ".join(COLUMNS)}, updated_at
)
SELECT {", ".join(COLUMNS)}, CURRENT_TIMESTAMP
FROM {STAGING_TABLE}
ON CONFLICT (client_id) DO UPDATE SET
    next_best_action    = EXCLUDED.next_best_action,
    propensity_score    = EXCLUDED.propensity_score,
    recommended_channel = EXCLUDED.recommended_channel,
    optimal_time_slot   = EXCLUDED.optimal_time_slot,
    optimal_day         = EXCLUDED.optimal_day,
    eligibility_status  = EXCLUDED.eligibility_status,
    exclusion_reason    = EXCLUDED.exclusion_reason,
    model_version       = EXCLUDED.model_version,
    updated_at          = CURRENT_TIMESTAMP;
"""


class RecommendationLoader:
    """Écrit les recommandations en base via staging + UPSERT."""

    def __init__(self, settings: Settings | None = None, connection=None) -> None:
        self.settings = settings or get_settings()
        self._external_conn = connection

    def _connect(self):
        if self._external_conn is not None:
            return self._external_conn
        return psycopg2.connect(self.settings.database.dsn)

    # ------------------------------------------------------------------ #
    def load(self, df: pd.DataFrame, use_copy: bool = True) -> int:
        """
        Charge le DataFrame `df` (colonnes = COLUMNS) et retourne le nombre de
        lignes traitées. Toute l'opération est transactionnelle.
        """
        rows = self._frame_to_rows(df)
        if not rows:
            logger.info("Aucune ligne à charger.")
            return 0

        conn = self._connect()
        started = time.perf_counter()
        try:
            with conn:  # transaction implicite (commit/rollback auto)
                with conn.cursor() as cur:
                    cur.execute(f"TRUNCATE TABLE {STAGING_TABLE};")
                    if use_copy:
                        self._copy_into_staging(cur, rows)
                    else:
                        self._execute_values_into_staging(cur, rows)
                    cur.execute(_UPSERT_SQL)
            elapsed = time.perf_counter() - started
            logger.info("Chargé %s lignes en %.2fs (COPY=%s)", len(rows), elapsed, use_copy)
            return len(rows)
        finally:
            if self._external_conn is None:
                conn.close()

    # ------------------------------------------------------------------ #
    @staticmethod
    def _frame_to_rows(df: pd.DataFrame) -> list[tuple]:
        if df.empty:
            return []
        missing = [c for c in COLUMNS if c not in df.columns]
        if missing:
            raise ValueError(f"Colonnes manquantes pour le chargement: {missing}")
        subset = df[list(COLUMNS)].copy()
        subset["eligibility_status"] = subset["eligibility_status"].astype(bool)
        # Normalise tout NaN/NaT en None -> devient NULL en base (jamais 'nan').
        subset = subset.astype(object).where(pd.notnull(subset), None)
        return list(subset.itertuples(index=False, name=None))

    @staticmethod
    def _copy_into_staging(cur, rows: Sequence[tuple]) -> None:
        buffer = io.StringIO()
        writer = csv.writer(buffer, delimiter="\t", quoting=csv.QUOTE_MINIMAL)
        for row in rows:
            writer.writerow(["" if v is None else v for v in row])
        buffer.seek(0)
        cur.copy_expert(
            f"COPY {STAGING_TABLE} ({', '.join(COLUMNS)}) "
            f"FROM STDIN WITH (FORMAT csv, DELIMITER E'\\t', NULL '')",
            buffer,
        )

    @staticmethod
    def _execute_values_into_staging(cur, rows: Iterable[tuple]) -> None:
        extras.execute_values(
            cur,
            f"INSERT INTO {STAGING_TABLE} ({', '.join(COLUMNS)}) VALUES %s",
            rows,
            page_size=5_000,
        )

    # ------------------------------------------------------------------ #
    def ensure_schema(self, ddl_paths: Sequence[str]) -> None:
        """Exécute des scripts DDL (utile pour bootstrap / tests d'intégration)."""
        conn = self._connect()
        try:
            with conn:
                with conn.cursor() as cur:
                    for path in ddl_paths:
                        with open(path, "r", encoding="utf-8") as fh:
                            cur.execute(fh.read())
        finally:
            if self._external_conn is None:
                conn.close()
