"""
Schémas Pydantic (api/schemas.py) — contrats d'entrée/sortie du micro-service.
"""
from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class ChannelEnum(str, Enum):
    PUSH_APP = "PUSH_APP"
    SMS = "SMS"
    EMAIL = "EMAIL"
    AGENCY_CALL = "AGENCY_CALL"


class CRMOpportunityRequest(BaseModel):
    """Payload reçu quand recommended_channel == 'AGENCY_CALL'."""

    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    client_id: str = Field(alias="ClientId", min_length=1, max_length=50)
    recommended_product: str = Field(alias="RecommendedProduct", min_length=1, max_length=50)
    propensity_score: float = Field(alias="PropensityScore", ge=0.0, le=1.0)
    suggested_pitch: str = Field(alias="SuggestedPitch", min_length=1, max_length=500)


class CRMOpportunityResponse(BaseModel):
    status: str
    crm_opportunity_id: str | None = None
    client_id: str
    message: str


class RecommendationResponse(BaseModel):
    """Lecture temps réel d'une recommandation depuis la table de restitution."""

    client_id: str
    next_best_action: str
    propensity_score: float
    recommended_channel: ChannelEnum
    optimal_time_slot: str
    optimal_day: str
    eligibility_status: bool
    exclusion_reason: str | None = None
    model_version: str


class HealthResponse(BaseModel):
    status: str
    model_version: str
