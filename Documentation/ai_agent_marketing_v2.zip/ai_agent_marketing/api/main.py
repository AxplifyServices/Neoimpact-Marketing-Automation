"""
Micro-service FastAPI (api/main.py).

Deux usages :
  - Lecture temps réel d'une recommandation par le CRM / front agence.
  - Webhook POST /api/v1/crm/opportunities : pousse une opportunité vers le CRM
    de la banque via un appel sécurisé httpx avec retries (tenacity).

Aucune PII n'est envoyée à une API externe : la cible est le CRM interne
on-premise (config CRM_BASE_URL) et l'egress externe est bloqué par défaut.
"""
from __future__ import annotations

import logging

import httpx
import psycopg2
from fastapi import FastAPI, HTTPException, status
from psycopg2.extras import RealDictCursor
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from api.schemas import (
    CRMOpportunityRequest,
    CRMOpportunityResponse,
    HealthResponse,
    RecommendationResponse,
)
from config.settings import get_settings

logger = logging.getLogger("api")

app = FastAPI(
    title="Agent IA Marketing Bancaire — API",
    version="1.0.0",
    description="Requêtage temps réel des recommandations IA + webhook CRM agence.",
)


# --------------------------------------------------------------------------- #
# Accès base (lecture temps réel)
# --------------------------------------------------------------------------- #
def _get_connection():
    settings = get_settings()
    return psycopg2.connect(settings.database.dsn)


@app.get("/health", response_model=HealthResponse, tags=["ops"])
def health() -> HealthResponse:
    return HealthResponse(status="ok", model_version=get_settings().model.model_version)


@app.get(
    "/api/v1/recommendations/{client_id}",
    response_model=RecommendationResponse,
    tags=["recommendations"],
)
def get_recommendation(client_id: str) -> RecommendationResponse:
    """Retourne la recommandation IA courante d'un client."""
    try:
        conn = _get_connection()
    except Exception as exc:  # pragma: no cover - dépend de l'infra
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Base indisponible") from exc
    try:
        with conn, conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                SELECT client_id, next_best_action, propensity_score, recommended_channel,
                       optimal_time_slot, optimal_day, eligibility_status,
                       exclusion_reason, model_version
                FROM ai_customer_recommendations
                WHERE client_id = %s
                """,
                (client_id,),
            )
            row = cur.fetchone()
    finally:
        conn.close()

    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Client inconnu")
    return RecommendationResponse(**row)


# --------------------------------------------------------------------------- #
# Webhook CRM agence
# --------------------------------------------------------------------------- #
class CRMClient:
    """Client HTTP sécurisé vers le CRM interne, avec retries exponentiels."""

    def __init__(self) -> None:
        self.settings = get_settings().crm

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=8),
        retry=retry_if_exception_type((httpx.TransportError, httpx.HTTPStatusError)),
        reraise=True,
    )
    def push_opportunity(self, payload: dict) -> dict:
        headers = {
            "Authorization": f"Bearer {self.settings.api_key}",
            "Content-Type": "application/json",
        }
        with httpx.Client(
            base_url=self.settings.base_url,
            timeout=self.settings.timeout_seconds,
            verify=self.settings.verify_ssl,
        ) as client:
            response = client.post("/opportunities", json=payload, headers=headers)
            response.raise_for_status()
            return response.json()


@app.post(
    "/api/v1/crm/opportunities",
    response_model=CRMOpportunityResponse,
    status_code=status.HTTP_202_ACCEPTED,
    tags=["crm"],
)
def create_crm_opportunity(request: CRMOpportunityRequest) -> CRMOpportunityResponse:
    """Reçoit une reco AGENCY_CALL et la pousse au CRM de la banque."""
    payload = {
        "clientId": request.client_id,
        "product": request.recommended_product,
        "score": request.propensity_score,
        "pitch": request.suggested_pitch,
        "source": "AI_MARKETING_AGENT",
    }
    try:
        crm_response = CRMClient().push_opportunity(payload)
    except httpx.HTTPStatusError as exc:  # pragma: no cover - dépend du CRM
        logger.error("CRM a répondu %s: %s", exc.response.status_code, exc.response.text)
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, "Le CRM a rejeté l'opportunité") from exc
    except httpx.TransportError as exc:  # pragma: no cover
        logger.error("CRM injoignable après retries: %s", exc)
        raise HTTPException(status.HTTP_504_GATEWAY_TIMEOUT, "CRM injoignable") from exc

    return CRMOpportunityResponse(
        status="ACCEPTED",
        crm_opportunity_id=str(crm_response.get("id")) if crm_response else None,
        client_id=request.client_id,
        message="Opportunité transmise au CRM agence.",
    )
