"""
Orchestrateur du batch nocturne (pipelines/daily_batch.py).

Enchaîne : extraction -> scoring propension (par produit) -> NBA -> STO ->
conformité (BAM/CNDP/pression) -> chargement PostgreSQL.

Exécutable de deux façons :
  1. Script autonome (cron) :  `python -m pipelines.daily_batch`
  2. DAG Airflow : `dag` est exposé si Airflow est installé (import paresseux).
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from config.settings import get_settings
from data.extractors import (
    CANDIDATE_PRODUCTS,
    CATEGORICAL_FEATURES,
    NUMERIC_FEATURES,
    BaseExtractor,
    SyntheticExtractor,
    get_default_extractor,
)
from data.loaders import COLUMNS, RecommendationLoader
from models.propensity_model import PropensityPredictor
from models.recommender import NextBestActionRecommender
from models.timing import SendTimeOptimizer
from rules.compliance import BankComplianceEngine

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s :: %(message)s")
logger = logging.getLogger("daily_batch")


def _score_all_products(
    features: pd.DataFrame, labels_by_product: dict[str, np.ndarray]
) -> pd.DataFrame:
    """Entraîne un modèle par produit et retourne une matrice de scores.

    En production les modèles seraient chargés depuis le registre d'artefacts
    plutôt que réentraînés ; ici on illustre le flux complet de bout en bout.
    """
    scores: dict[str, np.ndarray] = {}
    for product in CANDIDATE_PRODUCTS:
        y = labels_by_product[product]
        predictor = PropensityPredictor(
            numeric_features=NUMERIC_FEATURES,
            categorical_features=CATEGORICAL_FEATURES,
        )
        predictor.fit(features, y)
        result = predictor.predict(features, features["client_id"].tolist())
        scores[product] = result.scores
    matrix = pd.DataFrame(scores, index=features["client_id"].astype(str))
    return matrix


def run_daily_batch(extractor: BaseExtractor | None = None, load_to_db: bool = True) -> pd.DataFrame:
    """Exécute le pipeline complet et retourne le DataFrame final restitué."""
    settings = get_settings()
    extractor = extractor or get_default_extractor()

    logger.info("1/6 Extraction des données...")
    features = extractor.extract_customer_features()
    engagement = extractor.extract_engagement_history()
    contactability = extractor.extract_contactability()

    logger.info("2/6 Scoring de propension par produit...")
    if isinstance(extractor, SyntheticExtractor):
        labels = {p: extractor.build_training_labels(features) for p in CANDIDATE_PRODUCTS}
    else:  # pragma: no cover - dépend de la source réelle
        labels = {p: features.get(f"label_{p}", np.zeros(len(features), dtype=int)) for p in CANDIDATE_PRODUCTS}
    propensity_matrix = _score_all_products(features, labels)

    logger.info("3/6 Next Best Action + routing canal...")
    nba = NextBestActionRecommender().recommend(propensity_matrix, contactability)
    reco = nba.frame

    logger.info("4/6 Send Time Optimization...")
    timing = SendTimeOptimizer().optimize(engagement_history=engagement).frame
    reco = reco.merge(timing, on="client_id", how="left")
    reco["optimal_time_slot"] = reco["optimal_time_slot"].fillna("AFTERNOON_14H")
    reco["optimal_day"] = reco["optimal_day"].fillna("TUESDAY")

    logger.info("5/6 Application des filtres de conformité...")
    reco = reco.merge(
        features[["client_id", "has_cndp_consent", "debt_ratio", "has_bam_incident",
                  "days_since_last_solicitation"]],
        on="client_id",
        how="left",
    )
    reco = BankComplianceEngine().apply(reco)

    # Les clients sous le seuil de propension sont marqués inéligibles.
    below = reco.get("_below_threshold", pd.Series(False, index=reco.index)).fillna(False)
    reco.loc[below & reco["eligibility_status"], "exclusion_reason"] = "LOW_PROPENSITY"
    reco.loc[below, "eligibility_status"] = False

    reco["model_version"] = settings.model.model_version
    final = reco[list(COLUMNS)].copy()

    logger.info("6/6 Chargement en base (%s lignes)...", len(final))
    if load_to_db:
        RecommendationLoader(settings).load(final, use_copy=True)
    else:
        logger.info("Chargement DB désactivé (dry-run).")

    logger.info("Batch terminé : %s éligibles / %s clients",
                int(final["eligibility_status"].sum()), len(final))
    return final


# --------------------------------------------------------------------------- #
# Intégration Airflow (import paresseux : ne casse pas si Airflow est absent).
# --------------------------------------------------------------------------- #
def _build_airflow_dag():  # pragma: no cover - exécuté seulement dans Airflow
    from datetime import datetime, timedelta

    from airflow import DAG
    from airflow.operators.python import PythonOperator

    default_args = {
        "owner": "data-ai",
        "retries": 2,
        "retry_delay": timedelta(minutes=5),
    }
    dag = DAG(
        dag_id="ai_marketing_daily_batch",
        description="Batch nocturne de recommandations IA marketing bancaire",
        schedule_interval="0 2 * * *",  # tous les jours à 02:00
        start_date=datetime(2024, 1, 1),
        catchup=False,
        default_args=default_args,
        tags=["marketing", "ai", "banking"],
    )
    PythonOperator(
        task_id="run_daily_batch",
        python_callable=run_daily_batch,
        dag=dag,
    )
    return dag


try:  # pragma: no cover
    import airflow  # noqa: F401

    dag = _build_airflow_dag()
except Exception:  # Airflow absent : mode script uniquement.
    dag = None


if __name__ == "__main__":
    run_daily_batch()
