"""
Moteur de conformité bancaire (rules/compliance.py).

Applique, de manière vectorisée sur un DataFrame client, les filtres métier
réglementaires AVANT toute restitution marketing :

1. CNDP / Opt-In            -> 'NO_CNDP_CONSENT'
2. BAM / Surendettement     -> 'OVERINDEBTEDNESS_RISK'
3. Pression commerciale     -> 'MAX_PRESSURE_REACHED'

La règle est "fail-closed" : à la moindre violation, le client est rendu
inéligible (eligibility_status = False) et la première raison rencontrée dans
l'ordre de priorité ci-dessus est inscrite dans exclusion_reason.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum

import numpy as np
import pandas as pd

from config.settings import CREDIT_PRODUCTS, RiskThresholds, get_settings

logger = logging.getLogger(__name__)


class ExclusionReason(str, Enum):
    """Codes normalisés d'exclusion (alignés sur la colonne SQL)."""

    NO_CNDP_CONSENT = "NO_CNDP_CONSENT"
    OVERINDEBTEDNESS_RISK = "OVERINDEBTEDNESS_RISK"
    MAX_PRESSURE_REACHED = "MAX_PRESSURE_REACHED"
    LOW_PROPENSITY = "LOW_PROPENSITY"


# Colonnes attendues en entrée et valeur de repli conservatrice (fail-closed).
_REQUIRED_COLUMNS: dict[str, object] = {
    "client_id": None,
    "has_cndp_consent": False,          # absence de consentement => exclu
    "debt_ratio": 1.0,                  # endettement inconnu => exclu
    "has_bam_incident": True,           # incident inconnu => exclu
    "days_since_last_solicitation": 0,  # sollicitation inconnue => exclu
    "next_best_action": "",
}


@dataclass(frozen=True)
class ComplianceReport:
    """Résumé chiffré d'une passe de conformité (observabilité / audit)."""

    total: int
    eligible: int
    excluded_cndp: int
    excluded_debt: int
    excluded_pressure: int

    @property
    def excluded(self) -> int:
        return self.total - self.eligible


class BankComplianceEngine:
    """Applique les filtres réglementaires sur un DataFrame client."""

    def __init__(self, thresholds: RiskThresholds | None = None) -> None:
        self.thresholds = thresholds or get_settings().risk

    # ------------------------------------------------------------------ #
    # API publique
    # ------------------------------------------------------------------ #
    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Retourne une COPIE du DataFrame enrichie de deux colonnes :
        `eligibility_status` (bool) et `exclusion_reason` (str | None).

        L'ordre de priorité des raisons est : CNDP > BAM > Pression.
        """
        if df.empty:
            out = df.copy()
            out["eligibility_status"] = pd.Series(dtype=bool)
            out["exclusion_reason"] = pd.Series(dtype=object)
            return out

        out = self._ensure_columns(df)

        # Masques booléens vectorisés (un seul passage sur les données).
        cndp_violation = ~out["has_cndp_consent"].astype(bool)

        is_credit = out["next_best_action"].isin(CREDIT_PRODUCTS)
        debt_violation = is_credit & (
            (out["debt_ratio"].astype(float) > self.thresholds.max_debt_ratio)
            | (out["has_bam_incident"].astype(bool))
        )

        pressure_violation = (
            out["days_since_last_solicitation"].astype(float)
            < self.thresholds.min_days_between_solicitations
        )

        # Application par priorité décroissante via np.select.
        conditions = [cndp_violation, debt_violation, pressure_violation]
        reasons = [
            ExclusionReason.NO_CNDP_CONSENT.value,
            ExclusionReason.OVERINDEBTEDNESS_RISK.value,
            ExclusionReason.MAX_PRESSURE_REACHED.value,
        ]
        # On calcule l'éligibilité depuis le tableau numpy (robuste aux
        # conversions None->NaN de pandas), puis on force des None Python dans
        # la colonne texte (une chaîne vide "" servant de sentinelle "éligible").
        selected = np.select(conditions, reasons, default="")
        is_eligible = selected == ""
        out["eligibility_status"] = is_eligible
        reason_series = pd.Series(selected, index=out.index, dtype=object)
        out["exclusion_reason"] = reason_series.mask(reason_series == "", None)

        report = ComplianceReport(
            total=len(out),
            eligible=int(out["eligibility_status"].sum()),
            excluded_cndp=int(cndp_violation.sum()),
            excluded_debt=int(debt_violation.sum()),
            excluded_pressure=int(pressure_violation.sum()),
        )
        logger.info(
            "Conformité: %s clients, %s éligibles, exclusions CNDP=%s BAM=%s pression=%s",
            report.total,
            report.eligible,
            report.excluded_cndp,
            report.excluded_debt,
            report.excluded_pressure,
        )
        return out

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _ensure_columns(df: pd.DataFrame) -> pd.DataFrame:
        """Garantit la présence des colonnes requises (fail-closed defaults)."""
        out = df.copy()
        for column, default in _REQUIRED_COLUMNS.items():
            if column not in out.columns:
                logger.warning("Colonne manquante '%s' -> défaut conservateur %r", column, default)
                out[column] = default
        return out
