"""Tests du moteur de conformité (BAM, CNDP, pression commerciale)."""
from __future__ import annotations

import pandas as pd

from rules.compliance import BankComplianceEngine, ExclusionReason


def test_overindebtedness_excludes_high_propensity_credit(base_client_frame):
    """Scénario clé : propension 0.95 sur CREDIT_CONSO mais endettement 0.48 -> exclu."""
    result = BankComplianceEngine().apply(base_client_frame)
    c1 = result.set_index("client_id").loc["C1"]
    assert c1["eligibility_status"] is False or c1["eligibility_status"] == False  # noqa: E712
    assert c1["exclusion_reason"] == ExclusionReason.OVERINDEBTEDNESS_RISK.value


def test_bam_incident_excludes_credit():
    df = pd.DataFrame(
        {
            "client_id": ["X"],
            "next_best_action": ["CREDIT_CONSO"],
            "has_cndp_consent": [True],
            "debt_ratio": [0.10],
            "has_bam_incident": [True],
            "days_since_last_solicitation": [60],
        }
    )
    out = BankComplianceEngine().apply(df)
    assert not out.loc[0, "eligibility_status"]
    assert out.loc[0, "exclusion_reason"] == ExclusionReason.OVERINDEBTEDNESS_RISK.value


def test_no_cndp_consent_excluded(base_client_frame):
    out = BankComplianceEngine().apply(base_client_frame).set_index("client_id")
    assert not out.loc["C4", "eligibility_status"]
    assert out.loc["C4", "exclusion_reason"] == ExclusionReason.NO_CNDP_CONSENT.value


def test_pressure_excluded(base_client_frame):
    out = BankComplianceEngine().apply(base_client_frame).set_index("client_id")
    assert not out.loc["C3", "eligibility_status"]
    assert out.loc["C3", "exclusion_reason"] == ExclusionReason.MAX_PRESSURE_REACHED.value


def test_eligible_client_passes(base_client_frame):
    out = BankComplianceEngine().apply(base_client_frame).set_index("client_id")
    assert out.loc["C2", "eligibility_status"]
    assert out.loc["C2", "exclusion_reason"] is None


def test_cndp_priority_over_debt():
    """CNDP prime sur BAM quand les deux violations coexistent."""
    df = pd.DataFrame(
        {
            "client_id": ["Z"],
            "next_best_action": ["CREDIT_CONSO"],
            "has_cndp_consent": [False],
            "debt_ratio": [0.90],
            "has_bam_incident": [True],
            "days_since_last_solicitation": [1],
        }
    )
    out = BankComplianceEngine().apply(df)
    assert out.loc[0, "exclusion_reason"] == ExclusionReason.NO_CNDP_CONSENT.value


def test_non_credit_product_ignores_debt():
    """L'endettement n'exclut pas un produit non-crédit (ex: EPARGNE)."""
    df = pd.DataFrame(
        {
            "client_id": ["E"],
            "next_best_action": ["EPARGNE_LIVRET"],
            "has_cndp_consent": [True],
            "debt_ratio": [0.99],
            "has_bam_incident": [True],
            "days_since_last_solicitation": [60],
        }
    )
    out = BankComplianceEngine().apply(df)
    assert out.loc[0, "eligibility_status"]
