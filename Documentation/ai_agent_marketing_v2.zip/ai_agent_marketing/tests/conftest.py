"""Fixtures partagées pour la suite de tests."""
from __future__ import annotations

import pandas as pd
import pytest


@pytest.fixture
def base_client_frame() -> pd.DataFrame:
    """DataFrame client minimal pour les tests de conformité et NBA."""
    return pd.DataFrame(
        {
            "client_id": ["C1", "C2", "C3", "C4"],
            "next_best_action": ["CREDIT_CONSO", "EPARGNE_LIVRET", "CREDIT_CONSO", "CARTE_GOLD"],
            "propensity_score": [0.95, 0.80, 0.60, 0.72],
            "has_cndp_consent": [True, True, True, False],
            "debt_ratio": [0.48, 0.20, 0.10, 0.30],
            "has_bam_incident": [False, False, False, False],
            "days_since_last_solicitation": [30, 30, 5, 30],
        }
    )
