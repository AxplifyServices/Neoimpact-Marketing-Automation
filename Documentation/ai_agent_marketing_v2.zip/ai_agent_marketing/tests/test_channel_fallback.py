"""Tests du routing multi-canal et de la logique de fallback."""
from __future__ import annotations

import pandas as pd

from models.recommender import NextBestActionRecommender, resolve_channel


def test_push_token_invalid_falls_back_to_sms():
    """Token Push App invalide/inexistant -> bascule automatique vers SMS."""
    assert resolve_channel("CARTE_GOLD", has_valid_push_token=False) == "SMS"


def test_push_token_valid_keeps_push():
    assert resolve_channel("CARTE_GOLD", has_valid_push_token=True) == "PUSH_APP"


def test_sms_without_mobile_falls_back_to_email():
    assert resolve_channel("CARTE_GOLD", has_valid_push_token=False, has_mobile=False) == "EMAIL"


def test_credit_routes_to_agency():
    assert resolve_channel("CREDIT_CONSO", has_valid_push_token=True) == "AGENCY_CALL"


def test_recommender_applies_fallback_end_to_end():
    matrix = pd.DataFrame(
        {"CARTE_GOLD": [0.9], "EPARGNE_LIVRET": [0.4]},
        index=["CLI1"],
    )
    contact = pd.DataFrame(
        {"client_id": ["CLI1"], "has_valid_push_token": [False], "has_email": [True], "has_mobile": [True]}
    )
    out = NextBestActionRecommender(min_score=0.0).recommend(matrix, contact).frame
    row = out.set_index("client_id").loc["CLI1"]
    assert row["next_best_action"] == "CARTE_GOLD"
    assert row["recommended_channel"] == "SMS"  # fallback appliqué


def test_recommender_picks_max_propensity():
    matrix = pd.DataFrame(
        {"CREDIT_CONSO": [0.3, 0.9], "EPARGNE_LIVRET": [0.8, 0.2]},
        index=["A", "B"],
    )
    out = NextBestActionRecommender(min_score=0.0).recommend(matrix).frame.set_index("client_id")
    assert out.loc["A", "next_best_action"] == "EPARGNE_LIVRET"
    assert out.loc["B", "next_best_action"] == "CREDIT_CONSO"
