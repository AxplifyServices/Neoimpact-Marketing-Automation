"""
Tests de performance du chargement batch.

Deux niveaux :
  - test unitaire "hors DB" : vérifie que la préparation set-based (buffer COPY)
    de 100 000 lignes reste largement sous la cible, sans dépendance externe.
  - test d'intégration (marqué `integration`) : exécute réellement le COPY +
    UPSERT contre une PostgreSQL si DATABASE_URL/DB_* est configuré.
"""
from __future__ import annotations

import io
import os
import time

import numpy as np
import pandas as pd
import pytest

from data.loaders import COLUMNS, RecommendationLoader

N_ROWS = 100_000
TARGET_SECONDS = 60


def _make_frame(n: int) -> pd.DataFrame:
    rng = np.random.default_rng(0)
    return pd.DataFrame(
        {
            "client_id": [f"CLI{i:07d}" for i in range(n)],
            "next_best_action": rng.choice(["CREDIT_CONSO", "CARTE_GOLD", "EPARGNE_LIVRET"], n),
            "propensity_score": np.round(rng.random(n), 4),
            "recommended_channel": rng.choice(["PUSH_APP", "SMS", "EMAIL", "AGENCY_CALL"], n),
            "optimal_time_slot": rng.choice(["MORNING_09H", "AFTERNOON_14H", "EVENING_20H"], n),
            "optimal_day": rng.choice(["MONDAY", "TUESDAY", "WEDNESDAY"], n),
            "eligibility_status": rng.random(n) > 0.3,
            "exclusion_reason": rng.choice([None, "MAX_PRESSURE_REACHED"], n),
            "model_version": "v1.0.0",
        }
    )


def test_copy_buffer_preparation_under_target():
    """La construction du buffer COPY de 100k lignes doit être bien < 60s."""
    df = _make_frame(N_ROWS)
    rows = RecommendationLoader._frame_to_rows(df)
    assert len(rows) == N_ROWS

    started = time.perf_counter()
    buffer = io.StringIO()
    import csv

    writer = csv.writer(buffer, delimiter="\t")
    for row in rows:
        writer.writerow(["" if v is None else v for v in row])
    elapsed = time.perf_counter() - started

    assert buffer.tell() > 0
    assert elapsed < TARGET_SECONDS, f"Préparation trop lente: {elapsed:.2f}s"


@pytest.mark.integration
def test_full_copy_upsert_against_postgres():
    """Chargement réel de 100k lignes en < 60s (nécessite une PostgreSQL)."""
    if not os.getenv("RUN_DB_TESTS"):
        pytest.skip("RUN_DB_TESTS non défini : test d'intégration DB ignoré.")

    import psycopg2

    conn = psycopg2.connect(get_dsn())
    loader = RecommendationLoader(connection=conn)
    loader.ensure_schema(
        [
            "sql/001_create_ai_customer_recommendations.sql",
            "sql/002_create_staging_table.sql",
        ]
    )
    df = _make_frame(N_ROWS)

    started = time.perf_counter()
    processed = loader.load(df, use_copy=True)
    elapsed = time.perf_counter() - started
    conn.close()

    assert processed == N_ROWS
    assert elapsed < TARGET_SECONDS, f"Chargement trop lent: {elapsed:.2f}s"


def get_dsn() -> str:
    from config.settings import get_settings

    return get_settings().database.dsn
