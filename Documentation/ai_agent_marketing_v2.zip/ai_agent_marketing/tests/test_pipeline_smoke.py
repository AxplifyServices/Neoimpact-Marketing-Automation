"""Test bout-en-bout du pipeline sur données synthétiques (sans DB)."""
from __future__ import annotations

from data.extractors import SyntheticExtractor
from data.loaders import COLUMNS
from pipelines.daily_batch import run_daily_batch


def test_daily_batch_dry_run_produces_valid_frame():
    extractor = SyntheticExtractor(n_customers=120, seed=7)
    final = run_daily_batch(extractor=extractor, load_to_db=False)

    # Toutes les colonnes de restitution sont présentes.
    assert list(final.columns) == list(COLUMNS)
    assert len(final) == 120

    # Contraintes de domaine.
    assert final["propensity_score"].between(0, 1).all()
    assert final["recommended_channel"].isin(["PUSH_APP", "SMS", "EMAIL", "AGENCY_CALL"]).all()
    assert final["eligibility_status"].dtype == bool

    # Les clients inéligibles ont une raison, les éligibles n'en ont pas.
    eligible = final[final["eligibility_status"]]
    excluded = final[~final["eligibility_status"]]
    assert eligible["exclusion_reason"].isna().all()
    assert excluded["exclusion_reason"].notna().all()
